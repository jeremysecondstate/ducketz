from __future__ import annotations

import hashlib
import gc
import itertools
import json
import math
import re
import shutil
import time
import warnings
import zipfile
from dataclasses import dataclass
from dataclasses import field
from datetime import date, timedelta
from pathlib import Path
from pathlib import PurePosixPath
from typing import Callable, Iterable, Mapping, Sequence

import pandas as pd
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

from datafetching.databento_storage import (
    MARKET_OPRA,
    clean_token,
    dataset_root,
    opra_partition_directory,
    symbol_scope_name,
    window_name,
)
from ml.artifacts import file_checksum, utc_timestamp
from datafetching.runtime_lock import interprocess_file_lock


DATASET = "OPRA.PILLAR"
PROVIDER = "databento-opra"
SYNC_VERSION = "databento-opra-standard-sync-v1"
PARTITION_VERSION = "databento-opra-partition-v1"
RECEIPT_VERSION = "databento-opra-partition-receipt-v1"
ENTITLEMENT_VERSION = "databento-opra-entitlement-v2"
HEALTH_VERSION = "databento-opra-health-v1"
BATCH_JOB_VERSION = "databento-opra-batch-job-v1"

L0_SCHEMAS = (
    "ohlcv-1s",
    "ohlcv-1m",
    "ohlcv-1h",
    "ohlcv-1d",
    "definition",
    "statistics",
    "status",
)
L1_SCHEMAS = ("cmbp-1", "tcbbo", "cbbo-1s", "cbbo-1m", "trades")
STANDARD_SCHEMAS = (*L0_SCHEMAS, *L1_SCHEMAS)
# Exact historical schemas whose freshness is a production dependency of the
# options-strategy model. Other Standard schemas remain selectable research
# history unless a separate production consumer is explicitly added.
OPRA_STRATEGY_HISTORY_SCHEMAS = ("ohlcv-1h", "cbbo-1m", "definition")

METADATA_TIMEOUT_SECONDS = 30
TIMESERIES_TIMEOUT_SECONDS = 300
DOWNLOAD_MAX_ATTEMPTS = 3
STORAGE_RESERVE_BYTES = 5 * 1024**3
STORAGE_EXPANSION_FACTOR = 2.0
MAX_EXACT_VALIDATION_ROWS = 25_000_000
TARGET_HIGH_VOLUME_PARTITION_ROWS = 20_000_000
MINIMUM_TIME_PARTITION_SECONDS = 1
HIGH_VOLUME_SCHEMAS = frozenset(("cmbp-1", "cbbo-1s"))
OPRA_BATCH_MIN_DAYS = 30
OPRA_BATCH_POLL_SECONDS = 5
OPRA_BATCH_PROGRESS_FILES = 25
STANDARD_PLAN_AUTHORITY = "docs/databento-plan/databento_standard_plan_data_access.md"
_BATCH_JOB_ID_RE = re.compile(r"^[A-Za-z0-9-]+$")
_BATCH_FILE_DATE_RE = re.compile(r"(?<!\d)(\d{8})(?!\d)")
_BATCH_DEFINITION_FALLBACK_FILENAME = "point-in-time-definition.dbn.zst"
_BATCH_DEFINITION_FALLBACK_SCHEMAS = frozenset(("ohlcv-1d", "ohlcv-1h"))
_TCBBO_SOURCE_ORDINAL_COLUMN = "source_record_ordinal"
_TCBBO_SOURCE_ORDINAL_BASIS = "zero-based-native-dbn-record-order"


class OpraSyncError(RuntimeError):
    """Canonical OPRA synchronization failed closed."""


class OpraCapacityError(OpraSyncError):
    """The requested canonical OPRA scope cannot fit on its destination volume."""


class OpraNoDataError(OpraSyncError):
    """A structurally valid provider response has no records for the request."""


@dataclass(frozen=True)
class SyncScope:
    schemas: tuple[str, ...] = STANDARD_SCHEMAS
    start: str | None = None
    end: str | None = None
    symbols: tuple[str, ...] = ()
    max_partitions: int | None = None


@dataclass(frozen=True)
class SyncResult:
    status: str
    completed_partitions: int
    skipped_partitions: int
    completed_rows: int
    completed_bytes: int
    errors: Mapping[str, str]
    health_path: Path


@dataclass
class _SyncProgress:
    completed_partitions: int = 0
    skipped_partitions: int = 0
    completed_rows: int = 0
    completed_bytes: int = 0
    errors: dict[str, str] = field(default_factory=dict)

    def absorb(self, other: "_SyncProgress") -> None:
        self.completed_partitions += other.completed_partitions
        self.skipped_partitions += other.skipped_partitions
        self.completed_rows += other.completed_rows
        self.completed_bytes += other.completed_bytes
        self.errors.update(other.errors)


def canonical_root(datastore_root: Path) -> Path:
    return dataset_root(datastore_root, market=MARKET_OPRA, dataset=DATASET)


def configure_client(client: object) -> None:
    for endpoint_name, timeout in (
        ("metadata", METADATA_TIMEOUT_SECONDS),
        ("timeseries", TIMESERIES_TIMEOUT_SECONDS),
    ):
        endpoint = getattr(client, endpoint_name, None)
        if endpoint is None or not hasattr(endpoint, "TIMEOUT"):
            raise TypeError(f"Databento client has no {endpoint_name} timeout control")
        setattr(endpoint, "TIMEOUT", timeout)


def discover_standard_entitlement(
    client: object,
    *,
    datastore_root: Path,
    observed_at: object | None = None,
) -> Mapping[str, object]:
    """Discover dataset and account bounds without issuing a timeseries download."""

    configure_client(client)
    metadata = getattr(client, "metadata")
    dataset_range = _retry(
        metadata.get_dataset_range,
        kwargs={"dataset": DATASET},
        operation="dataset range",
    )
    schemas = tuple(
        _retry(
            metadata.list_schemas,
            kwargs={"dataset": DATASET},
            operation="schema list",
        )
    )
    missing = sorted(set(STANDARD_SCHEMAS).difference(schemas))
    if missing:
        raise OpraSyncError(
            "Databento did not advertise required OPRA schemas: " + ", ".join(missing)
        )
    if not isinstance(dataset_range, Mapping):
        raise OpraSyncError("Databento returned a malformed OPRA dataset range")
    schema_ranges = dataset_range.get("schema")
    if not isinstance(schema_ranges, Mapping):
        raise OpraSyncError("Databento returned no schema-specific OPRA ranges")

    entitlements: dict[str, dict[str, object]] = {}
    for schema in STANDARD_SCHEMAS:
        raw_range = schema_ranges.get(schema)
        if not isinstance(raw_range, Mapping):
            raise OpraSyncError(f"Databento returned no range for {schema}")
        dataset_start = _date_text(raw_range["start"])
        dataset_end = _date_text(raw_range["end"])
        included_policy = standard_plan_history_policy(schema)
        plan_start = _history_window_start(dataset_end, included_policy)
        entitled_start = max(dataset_start, plan_start)
        if entitled_start >= dataset_end:
            raise OpraSyncError(
                f"Provider range does not overlap the configured Standard-plan "
                f"window for {schema}: provider_start={dataset_start} "
                f"included_start={plan_start} end={dataset_end}"
            )
        entitlements[schema] = {
            "level": "L0" if schema in L0_SCHEMAS else "L1",
            "dataset_start": dataset_start,
            "configured_included_start": plan_start,
            "entitled_start": entitled_start,
            "entitled_end": dataset_end,
            "included_history_policy": included_policy,
        }

    timestamp = utc_timestamp(observed_at)
    payload: dict[str, object] = {
        "schema_version": ENTITLEMENT_VERSION,
        "provider": PROVIDER,
        "dataset": DATASET,
        "observed_at": timestamp.isoformat(),
        "provider_dataset_range": dataset_range,
        "provider_schema_names": list(schemas),
        "standard_schema_names": list(STANDARD_SCHEMAS),
        "entitlement_authority": STANDARD_PLAN_AUTHORITY,
        "entitlements": entitlements,
    }
    payload["semantic_checksum_sha256"] = _semantic_checksum(payload)
    destination = canonical_root(datastore_root) / "metadata" / "entitlement.json"
    _write_json_atomic(destination, payload)
    return {**payload, "path": destination}


def storage_preflight(
    client: object,
    *,
    datastore_root: Path,
    entitlement: Mapping[str, object],
    scope: SyncScope,
) -> Mapping[str, object]:
    requests = _scope_ranges(entitlement, scope)
    metadata = getattr(client, "metadata")
    estimates: dict[str, dict[str, object]] = {}
    cost_estimates_complete = True
    for schema, start, end in requests:
        kwargs = _metadata_request_kwargs(
            schema=schema,
            start=start,
            end=end,
            symbols=scope.symbols,
        )
        estimated_download_size = int(
            _retry(
                metadata.get_billable_size,
                kwargs=kwargs,
                operation=f"{schema} estimated download size",
            )
        )
        records = int(
            _retry(
                metadata.get_record_count,
                kwargs=kwargs,
                operation=f"{schema} record count",
            )
        )
        get_cost = getattr(metadata, "get_cost", None)
        estimated_cost_usd = (
            float(
                _retry(
                    get_cost,
                    kwargs=kwargs,
                    operation=f"{schema} estimated cost",
                )
            )
            if callable(get_cost)
            else None
        )
        if estimated_cost_usd is not None and estimated_cost_usd < 0:
            raise OpraSyncError(
                f"Databento returned a negative estimated cost for {schema}"
            )
        cost_estimates_complete = (
            cost_estimates_complete and estimated_cost_usd is not None
        )
        estimates[schema] = {
            "start": start,
            "end": end,
            "symbols": list(scope.symbols) or ["ALL_SYMBOLS"],
            "estimated_download_size_bytes": estimated_download_size,
            "record_count": records,
            "estimated_cost_usd": estimated_cost_usd,
        }
    download_size_total = sum(
        int(item["estimated_download_size_bytes"]) for item in estimates.values()
    )
    record_total = sum(int(item["record_count"]) for item in estimates.values())
    estimated_cost_total = (
        sum(float(item["estimated_cost_usd"]) for item in estimates.values())
        if cost_estimates_complete
        else None
    )
    required = (
        math.ceil(download_size_total * STORAGE_EXPANSION_FACTOR)
        + STORAGE_RESERVE_BYTES
    )
    usage = shutil.disk_usage(canonical_root(datastore_root).anchor)
    return {
        "schema_version": "databento-opra-storage-preflight-v2",
        "provider": PROVIDER,
        "dataset": DATASET,
        "scope": {
            "schemas": list(scope.schemas),
            "symbols": list(scope.symbols) or ["ALL_SYMBOLS"],
            "start": min((start for _schema, start, _end in requests), default=None),
            "end": max((end for _schema, _start, end in requests), default=None),
        },
        "estimates": estimates,
        "estimated_download_size_bytes": download_size_total,
        "estimated_cost_usd": estimated_cost_total,
        "cost_estimates_complete": cost_estimates_complete,
        "record_count": record_total,
        "storage_expansion_factor": STORAGE_EXPANSION_FACTOR,
        "storage_reserve_bytes": STORAGE_RESERVE_BYTES,
        "required_free_bytes": required,
        "available_free_bytes": usage.free,
        "capacity_pass": usage.free >= required,
        "shortfall_bytes": max(required - usage.free, 0),
    }


def publish_storage_preflight(
    datastore_root: Path,
    preflight: Mapping[str, object],
) -> Mapping[str, object]:
    """Publish an immutable, checksummed record of a provider metadata preflight."""

    timestamp = utc_timestamp()
    payload = {
        **preflight,
        "generated_at": timestamp.isoformat(),
    }
    payload["semantic_checksum_sha256"] = _semantic_checksum(payload)
    destination = _storage_preflight_path(datastore_root, payload)
    _write_json_atomic(destination, payload)
    return {**payload, "path": destination}


def synchronize(
    client: object,
    *,
    datastore_root: Path,
    entitlement: Mapping[str, object],
    scope: SyncScope = SyncScope(),
    reporter: Callable[[str], None] | None = print,
    storage_preflight_receipt: Mapping[str, object] | None = None,
    fail_fast: bool = False,
    batch_download: bool = False,
    refresh_health: bool = True,
) -> SyncResult:
    """Download, normalize, publish, and verify immutable OPRA partitions."""

    root = canonical_root(datastore_root)
    root.mkdir(parents=True, exist_ok=True)
    configure_client(client)
    if storage_preflight_receipt is None:
        preflight = storage_preflight(
            client,
            datastore_root=datastore_root,
            entitlement=entitlement,
            scope=scope,
        )
        published_preflight = publish_storage_preflight(datastore_root, preflight)
    else:
        preflight = _validate_storage_preflight_receipt(
            storage_preflight_receipt,
            entitlement=entitlement,
            scope=scope,
        )
        published_preflight = {
            **preflight,
            "path": str(
                preflight.get(
                    "source",
                    "checksum-verified cold-start coordinator preflight",
                )
            ),
        }
    if not bool(preflight["capacity_pass"]):
        health = publish_health(datastore_root)
        raise OpraCapacityError(
            "OPRA storage preflight failed: "
            f"required_free_bytes={preflight['required_free_bytes']} "
            f"available_free_bytes={preflight['available_free_bytes']} "
            f"shortfall_bytes={preflight['shortfall_bytes']} "
            f"preflight={published_preflight['path']} health={health}"
        )

    plan = _partition_plan(client, entitlement=entitlement, scope=scope)
    if scope.max_partitions is not None and scope.max_partitions < 1:
        raise ValueError("max_partitions must be positive")
    if batch_download and scope.max_partitions is None:
        progress = _execute_batch_aware_plan(
            client,
            datastore_root=datastore_root,
            entitlement=entitlement,
            scope=scope,
            plan=plan,
            reporter=reporter,
            fail_fast=fail_fast,
        )
    else:
        progress = _execute_stream_plan(
            client,
            datastore_root=datastore_root,
            entitlement=entitlement,
            symbols=scope.symbols,
            plan=plan,
            reporter=reporter,
            fail_fast=fail_fast,
            max_partitions=scope.max_partitions,
        )
    for schema in sorted({schema for schema, _day in plan}):
        _publish_cursor(datastore_root, schema=schema)
    health = (
        publish_health(datastore_root)
        if refresh_health
        else canonical_root(datastore_root) / "health" / "current.json"
    )
    return SyncResult(
        status="COMPLETE" if not progress.errors else "PARTIAL",
        completed_partitions=progress.completed_partitions,
        skipped_partitions=progress.skipped_partitions,
        completed_rows=progress.completed_rows,
        completed_bytes=progress.completed_bytes,
        errors=progress.errors,
        health_path=health,
    )


def _execute_stream_plan(
    client: object,
    *,
    datastore_root: Path,
    entitlement: Mapping[str, object],
    symbols: Sequence[str],
    plan: Sequence[tuple[str, str]],
    reporter: Callable[[str], None] | None,
    fail_fast: bool,
    max_partitions: int | None = None,
) -> _SyncProgress:
    tasks: Iterable[tuple[str, str, str, str, str | None]] = (
        (schema, day, request_start, request_end, segment)
        for schema, day in plan
        for request_start, request_end, segment in _partition_time_segments(
            client,
            schema=schema,
            day=day,
            symbols=symbols,
        )
    )
    if max_partitions is not None:
        tasks = itertools.islice(tasks, max_partitions)
    progress = _SyncProgress()
    for schema, day, request_start, request_end, segment in tasks:
        key = f"{schema}/{day}" + (f"/{segment}" if segment else "")
        destination = partition_directory(
            datastore_root,
            schema=schema,
            day=day,
            symbols=symbols,
            segment=segment,
        )
        try:
            if destination.is_dir():
                verified = verify_partition(destination, datastore_root=datastore_root)
                progress.skipped_partitions += 1
                progress.completed_rows += int(
                    verified["manifest"]["normalized"]["row_count"]
                )
                progress.completed_bytes += int(
                    verified["manifest"]["normalized"]["size_bytes"]
                )
                if reporter:
                    reporter(f"VERIFIED_EXISTING {key}")
                continue
            manifest = _download_partition(
                client,
                datastore_root=datastore_root,
                entitlement=entitlement,
                schema=schema,
                day=day,
                symbols=symbols,
                request_start=request_start,
                request_end=request_end,
                segment=segment,
            )
            progress.completed_partitions += 1
            progress.completed_rows += int(manifest["normalized"]["row_count"])
            progress.completed_bytes += int(manifest["normalized"]["size_bytes"])
            if reporter:
                reporter(
                    f"PUBLISHED {key} rows={manifest['normalized']['row_count']} "
                    f"bytes={manifest['normalized']['size_bytes']}"
                )
        except OpraNoDataError as exc:
            progress.skipped_partitions += 1
            if reporter:
                reporter(f"NO_DATA {key} {exc}")
        except Exception as exc:
            progress.errors[key] = f"{type(exc).__name__}: {exc}"
            if reporter:
                reporter(f"FAILED {key} {progress.errors[key]}")
            if fail_fast:
                raise
    return progress


def _execute_batch_aware_plan(
    client: object,
    *,
    datastore_root: Path,
    entitlement: Mapping[str, object],
    scope: SyncScope,
    plan: Sequence[tuple[str, str]],
    reporter: Callable[[str], None] | None,
    fail_fast: bool,
) -> _SyncProgress:
    by_schema: dict[str, list[str]] = {}
    for schema, day in plan:
        by_schema.setdefault(schema, []).append(day)
    progress = _SyncProgress()
    for schema, days in by_schema.items():
        use_batch = (
            bool(scope.symbols)
            and schema not in HIGH_VOLUME_SCHEMAS
            and len(days) >= OPRA_BATCH_MIN_DAYS
        )
        try:
            if use_batch:
                current = _synchronize_daily_batch(
                    client,
                    datastore_root=datastore_root,
                    entitlement=entitlement,
                    schema=schema,
                    days=days,
                    symbols=scope.symbols,
                    reporter=reporter,
                )
            else:
                current = _execute_stream_plan(
                    client,
                    datastore_root=datastore_root,
                    entitlement=entitlement,
                    symbols=scope.symbols,
                    plan=[(schema, day) for day in days],
                    reporter=reporter,
                    fail_fast=fail_fast,
                )
            progress.absorb(current)
        except Exception as exc:
            key = f"{schema}/batch"
            progress.errors[key] = f"{type(exc).__name__}: {exc}"
            if reporter:
                reporter(f"FAILED {key} {progress.errors[key]}")
            if fail_fast:
                raise
    return progress


def _validate_storage_preflight_receipt(
    receipt: Mapping[str, object],
    *,
    entitlement: Mapping[str, object],
    scope: SyncScope,
) -> Mapping[str, object]:
    """Validate coordinator-owned estimates without calling provider metadata again."""

    if receipt.get("provider") != PROVIDER or receipt.get("dataset") != DATASET:
        raise OpraSyncError("Supplied OPRA storage preflight belongs to another provider scope")
    requests = _scope_ranges(entitlement, scope)
    estimates = receipt.get("estimates")
    if not isinstance(estimates, Mapping):
        raise OpraSyncError("Supplied OPRA storage preflight has no estimate map")
    expected_schemas = {schema for schema, _start, _end in requests}
    if set(str(schema) for schema in estimates) != expected_schemas:
        raise OpraSyncError("Supplied OPRA storage preflight has the wrong schema scope")
    total_size = 0
    total_records = 0
    expected_symbols = list(scope.symbols) or ["ALL_SYMBOLS"]
    for schema, start, end in requests:
        estimate = estimates.get(schema)
        if not isinstance(estimate, Mapping):
            raise OpraSyncError("Supplied OPRA storage preflight estimate is malformed")
        if (
            estimate.get("start") != start
            or estimate.get("end") != end
            or estimate.get("symbols") != expected_symbols
        ):
            raise OpraSyncError("Supplied OPRA storage preflight does not match the request")
        try:
            size = int(estimate["estimated_download_size_bytes"])
            records = int(estimate["record_count"])
        except (KeyError, TypeError, ValueError) as exc:
            raise OpraSyncError("Supplied OPRA storage preflight totals are malformed") from exc
        if size < 0 or records < 0:
            raise OpraSyncError("Supplied OPRA storage preflight contains negative values")
        total_size += size
        total_records += records
    required = math.ceil(total_size * STORAGE_EXPANSION_FACTOR) + STORAGE_RESERVE_BYTES
    expected_totals = {
        "estimated_download_size_bytes": total_size,
        "record_count": total_records,
        "storage_expansion_factor": STORAGE_EXPANSION_FACTOR,
        "storage_reserve_bytes": STORAGE_RESERVE_BYTES,
        "required_free_bytes": required,
    }
    for key, expected in expected_totals.items():
        if receipt.get(key) != expected:
            raise OpraSyncError(f"Supplied OPRA storage preflight has inconsistent {key}")
    try:
        available = int(receipt["available_free_bytes"])
    except (KeyError, TypeError, ValueError) as exc:
        raise OpraSyncError("Supplied OPRA storage preflight has no free-space check") from exc
    if bool(receipt.get("capacity_pass")) != (available >= required):
        raise OpraSyncError("Supplied OPRA storage preflight capacity result is inconsistent")
    if int(receipt.get("shortfall_bytes", -1)) != max(required - available, 0):
        raise OpraSyncError("Supplied OPRA storage preflight shortfall is inconsistent")
    return dict(receipt)


def partition_directory(
    datastore_root: Path,
    *,
    schema: str,
    day: str,
    symbols: Sequence[str] = (),
    segment: str | None = None,
) -> Path:
    return opra_partition_directory(
        datastore_root,
        dataset=DATASET,
        schema=schema,
        day=day,
        symbols=symbols,
        segment=segment,
    )


def symbol_bucket(symbols: Sequence[str]) -> str:
    """Return the readable scope component retained in manifests for compatibility."""

    return symbol_scope_name(symbols)


def verify_partition(directory: Path, *, datastore_root: Path) -> Mapping[str, object]:
    root = canonical_root(datastore_root).resolve()
    run = Path(directory).resolve()
    if root not in run.parents:
        raise OpraSyncError("OPRA partition escapes the canonical root")
    manifest_path = run / "manifest.json"
    receipt_path = run / "receipt.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise OpraSyncError("OPRA partition metadata is unreadable") from exc
    if (
        manifest.get("schema_version") != PARTITION_VERSION
        or receipt.get("schema_version") != RECEIPT_VERSION
        or receipt.get("manifest_checksum_sha256") != file_checksum(manifest_path)
    ):
        raise OpraSyncError("OPRA partition receipt does not match its manifest")
    for name in ("raw", "normalized"):
        info = manifest.get(name)
        if not isinstance(info, Mapping):
            raise OpraSyncError(f"OPRA partition has no {name} inventory")
        path = run / str(info.get("path"))
        if (
            not path.is_file()
            or path.stat().st_size != int(info.get("size_bytes", -1))
            or file_checksum(path) != info.get("checksum_sha256")
        ):
            raise OpraSyncError(f"OPRA partition {name} checksum verification failed")
    provider_delivery = manifest.get("provider_delivery")
    if provider_delivery is not None:
        if not isinstance(provider_delivery, Mapping) or provider_delivery.get("mode") not in {
            "timeseries-stream",
            "batch",
            "live-intraday-replay",
        }:
            raise OpraSyncError("OPRA partition has invalid provider delivery evidence")
        if provider_delivery.get("mode") == "batch":
            provider_hash = str(provider_delivery.get("provider_hash", ""))
            partial_symbol_count = provider_delivery.get(
                "partially_resolved_symbol_count"
            )
            if (
                not str(provider_delivery.get("job_id", "")).strip()
                or not str(provider_delivery.get("filename", "")).strip()
                or provider_hash.partition(":")[0] != "sha256"
                or provider_hash.partition(":")[2]
                != str(manifest["raw"]["checksum_sha256"])
                or (
                    partial_symbol_count is not None
                    and (
                        not isinstance(partial_symbol_count, int)
                        or partial_symbol_count < 0
                    )
                )
                or (
                    isinstance(partial_symbol_count, int)
                    and partial_symbol_count > 0
                    and provider_delivery.get("normalized_symbol_mapping")
                    != "complete"
                )
            ):
                raise OpraSyncError("OPRA partition batch delivery evidence is incomplete")
            fallback = provider_delivery.get("symbol_mapping_fallback")
            if fallback is not None:
                _verify_symbol_mapping_fallback_evidence(
                    run,
                    fallback,
                    schema=str(manifest["schema"]),
                )
        elif provider_delivery.get("mode") == "live-intraday-replay":
            _validate_live_replay_publication(
                provider_delivery,
                request=manifest.get("request"),
                raw_path=run / str(manifest["raw"]["path"]),
                segment=manifest.get("time_segment"),
            )
    parquet_path = run / str(manifest["normalized"]["path"])
    live_replay = isinstance(provider_delivery, Mapping) and (
        provider_delivery.get("mode") == "live-intraday-replay"
    )
    validation = validate_parquet(
        parquet_path,
        schema=str(manifest["schema"]),
        partition_timestamp_column=(
            _live_replay_partition_clock(str(manifest["schema"])) if live_replay else None
        ),
    )
    if live_replay:
        _verify_live_replay_normalization(manifest, validation, parquet_path)
    expected = manifest["normalized"]
    for key in (
        "row_count",
        "earliest_event_timestamp",
        "latest_event_timestamp",
        "partition_timestamp_column",
        "earliest_partition_timestamp",
        "latest_partition_timestamp",
        "duplicate_natural_key_rows",
        "source_record_identity",
    ):
        if key in expected and validation.get(key) != expected.get(key):
            raise OpraSyncError(f"OPRA partition normalized {key} changed")
    return {"manifest": manifest, "receipt": receipt, "directory": run}


def validate_parquet(
    path: Path, *, schema: str, partition_timestamp_column: str | None = None
) -> Mapping[str, object]:
    parquet = pq.ParquetFile(path)
    names = tuple(parquet.schema_arrow.names)
    event_column = _event_column(names)
    partition_column = partition_timestamp_column or (
        "ts_recv" if schema in HIGH_VOLUME_SCHEMAS and "ts_recv" in names else event_column
    )
    if partition_timestamp_column is not None and partition_timestamp_column not in names:
        raise OpraSyncError("Databento normalized Parquet lacks its partition clock")
    row_count = int(parquet.metadata.num_rows)
    bounds: dict[str, list[pd.Timestamp | None]] = {
        column: [None, None]
        for column in dict.fromkeys(
            column for column in (event_column, partition_column) if column is not None
        )
    }
    null_counts = {name: 0 for name in names}
    for batch in parquet.iter_batches(batch_size=250_000):
        for index, name in enumerate(names):
            null_counts[name] += int(batch.column(index).null_count)
        for timestamp_column, timestamp_bounds in bounds.items():
            column = batch.column(names.index(timestamp_column))
            if len(column) and column.null_count < len(column):
                minimum = pc.min(column).as_py()
                maximum = pc.max(column).as_py()
                minimum_ts = pd.to_datetime(minimum, utc=True, errors="coerce")
                maximum_ts = pd.to_datetime(maximum, utc=True, errors="coerce")
                if not pd.isna(minimum_ts):
                    timestamp_bounds[0] = (
                        min(timestamp_bounds[0], minimum_ts)
                        if timestamp_bounds[0] is not None
                        else minimum_ts
                    )
                if not pd.isna(maximum_ts):
                    timestamp_bounds[1] = (
                        max(timestamp_bounds[1], maximum_ts)
                        if timestamp_bounds[1] is not None
                        else maximum_ts
                    )
    event_bounds = bounds.get(event_column, [None, None])
    partition_bounds = bounds.get(partition_column, [None, None])
    source_record_identity = (
        _validate_tcbbo_source_record_identity(path, row_count=row_count)
        if schema == "tcbbo"
        else None
    )
    natural_key = tuple(name for name in _natural_key(schema) if name in names)
    duplicate_rows = _duplicate_rows(path, columns=natural_key, row_count=row_count)
    result: dict[str, object] = {
        "parquet_schema": str(parquet.schema_arrow),
        "columns": list(names),
        "row_count": row_count,
        "event_timestamp_column": event_column,
        "earliest_event_timestamp": (
            event_bounds[0].isoformat() if event_bounds[0] is not None else None
        ),
        "latest_event_timestamp": (
            event_bounds[1].isoformat() if event_bounds[1] is not None else None
        ),
        "partition_timestamp_column": partition_column,
        "earliest_partition_timestamp": (
            partition_bounds[0].isoformat() if partition_bounds[0] is not None else None
        ),
        "latest_partition_timestamp": (
            partition_bounds[1].isoformat() if partition_bounds[1] is not None else None
        ),
        "null_counts": null_counts,
        "null_rates": {
            name: (count / row_count if row_count else 0.0)
            for name, count in null_counts.items()
        },
        "natural_key_columns": list(natural_key),
        "duplicate_natural_key_rows": duplicate_rows,
        "duplicate_natural_key_rate": duplicate_rows / row_count if row_count else 0.0,
    }
    if source_record_identity is not None:
        result["source_record_identity"] = source_record_identity
    return result


def iter_verified_partitions(
    datastore_root: Path,
    *,
    schemas: Iterable[str] | None = None,
) -> Iterable[Mapping[str, object]]:
    root = canonical_root(datastore_root)
    selected = set(schemas or STANDARD_SCHEMAS)
    for schema in sorted(selected):
        for receipt in sorted(root.glob(f"{clean_token(schema)}/*/dates/*/segments/*/receipt.json")):
            try:
                verified = verify_partition(receipt.parent, datastore_root=datastore_root)
            except OpraSyncError:
                continue
            if historical_full_day_supersedes_replay(
                receipt.parent, datastore_root=datastore_root, manifest=verified["manifest"]
            ):
                continue
            yield verified


def historical_full_day_supersedes_replay(
    directory: Path, *, datastore_root: Path, manifest: Mapping[str, object]
) -> bool:
    """Prefer a verified matching Historical day without deleting replay evidence.

    Only Live session deliveries participate in this precedence rule. Ordinary
    intraday Historical segments retain their existing selection behavior.
    A conflicting but corrupt Historical directory is an explicit blocker.
    """
    delivery = manifest.get("provider_delivery")
    if (
        not directory.name.startswith("live-session")
        or not isinstance(delivery, Mapping)
        or delivery.get("mode") != "live-intraday-replay"
    ):
        return False
    historical = directory.parent / "full-day"
    if not historical.exists():
        return False
    try:
        full = verify_partition(historical, datastore_root=datastore_root)["manifest"]
        request = manifest["request"]
        full_request = full["request"]
        day_start = pd.Timestamp(str(manifest["partition_date"]), tz="UTC")
        day_end = day_start + pd.Timedelta(days=1)
        identity_matches = (
            full.get("provider") == manifest.get("provider") == PROVIDER
            and full.get("dataset") == manifest.get("dataset") == DATASET
            and full.get("schema") == manifest.get("schema")
            and full.get("partition_date") == manifest.get("partition_date")
            and full.get("symbol_scope") == manifest.get("symbol_scope")
            and full.get("time_segment") in (None, "full-day")
            and full.get("provider_delivery", {}).get("mode", "timeseries-stream")
            in ("timeseries-stream", "batch")
            and all(full_request.get(key) == request.get(key)
                    for key in ("dataset", "schema", "symbols", "stype_in"))
            and pd.to_datetime(full["partition_start"], utc=True) == day_start
            and pd.to_datetime(full["partition_end"], utc=True) == day_end
            and pd.to_datetime(full_request["start"], utc=True) == day_start
            and pd.to_datetime(full_request["end"], utc=True) == day_end
            and day_start <= pd.to_datetime(manifest["partition_start"], utc=True)
            < pd.to_datetime(manifest["partition_end"], utc=True) <= day_end
        )
        if not identity_matches:
            raise OpraSyncError("Historical full-day scope does not match the Live session")
    except (KeyError, OSError, TypeError, ValueError, OpraSyncError) as exc:
        raise OpraSyncError(
            f"Conflicting Historical full-day cannot supersede replay: {historical}: {exc}"
        ) from exc
    return True


def publish_health(datastore_root: Path) -> Path:
    root = canonical_root(datastore_root)
    by_schema: dict[str, dict[str, object]] = {}
    for verified in iter_verified_partitions(datastore_root):
        manifest = verified["manifest"]
        schema = str(manifest["schema"])
        normalized = manifest["normalized"]
        item = by_schema.setdefault(
            schema,
            {
                "partition_count": 0,
                "row_count": 0,
                "raw_bytes": 0,
                "parquet_bytes": 0,
                "earliest_event_timestamp": None,
                "latest_event_timestamp": None,
                "consumer_read_count": 0,
            },
        )
        item["partition_count"] = int(item["partition_count"]) + 1
        item["row_count"] = int(item["row_count"]) + int(normalized["row_count"])
        item["raw_bytes"] = int(item["raw_bytes"]) + int(manifest["raw"]["size_bytes"])
        item["parquet_bytes"] = int(item["parquet_bytes"]) + int(normalized["size_bytes"])
        item["earliest_event_timestamp"] = _minimum_timestamp_text(
            item["earliest_event_timestamp"], normalized["earliest_event_timestamp"]
        )
        item["latest_event_timestamp"] = _maximum_timestamp_text(
            item["latest_event_timestamp"], normalized["latest_event_timestamp"]
        )
    usage_path = root / "state" / "consumer-usage.json"
    if usage_path.is_file():
        try:
            usage = json.loads(usage_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            usage = {}
        if isinstance(usage, Mapping):
            for schema, count in usage.get("schema_read_counts", {}).items():
                if schema in by_schema:
                    by_schema[schema]["consumer_read_count"] = int(count)
    payload = {
        "schema_version": HEALTH_VERSION,
        "provider": PROVIDER,
        "dataset": DATASET,
        "observed_at": utc_timestamp().isoformat(),
        "canonical_root": root.as_posix(),
        "schemas": by_schema,
        "total_partitions": sum(int(item["partition_count"]) for item in by_schema.values()),
        "total_rows": sum(int(item["row_count"]) for item in by_schema.values()),
        "total_raw_bytes": sum(int(item["raw_bytes"]) for item in by_schema.values()),
        "total_parquet_bytes": sum(int(item["parquet_bytes"]) for item in by_schema.values()),
    }
    path = root / "health" / "current.json"
    _write_json_atomic(path, payload)
    return path


def record_consumer_usage(
    datastore_root: Path,
    *,
    consumer: str,
    schemas: Sequence[str],
    rows: int,
    source_files: Sequence[Path],
    refresh_health: bool = True,
) -> Path:
    root = canonical_root(datastore_root)
    path = root / "state" / "consumer-usage.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    except json.JSONDecodeError:
        payload = {}
    counts = dict(payload.get("schema_read_counts", {}))
    for schema in schemas:
        counts[schema] = int(counts.get(schema, 0)) + 1
    events = [
        _compact_consumer_usage_event(value)
        for value in payload.get("events", ())
        if isinstance(value, Mapping)
    ]
    resolved_sources = tuple(
        sorted({Path(value).resolve().as_posix() for value in source_files})
    )
    source_fingerprint = hashlib.sha256(
        "\n".join(resolved_sources).encode("utf-8")
    ).hexdigest()
    events.append(
        {
            "consumer": str(consumer),
            "consumed_at": utc_timestamp().isoformat(),
            "schemas": list(schemas),
            "rows": int(rows),
            "source_file_count": len(resolved_sources),
            "source_files_sha256": source_fingerprint,
            "source_file_examples": list(resolved_sources[:8]),
        }
    )
    _write_json_atomic(
        path,
        {
            "schema_version": "databento-opra-consumer-usage-v2",
            "schema_read_counts": counts,
            "events": events[-1_000:],
        },
    )
    if refresh_health:
        refresh_health_consumer_usage(datastore_root)
    return path


def refresh_health_consumer_usage(datastore_root: Path) -> Path:
    """Refresh usage counters without rehashing the full immutable OPRA archive."""

    root = canonical_root(datastore_root)
    health_path = root / "health" / "current.json"
    if not health_path.is_file():
        return publish_health(datastore_root)
    try:
        health = json.loads(health_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return publish_health(datastore_root)
    if (
        not isinstance(health, Mapping)
        or health.get("schema_version") != HEALTH_VERSION
        or health.get("dataset") != DATASET
        or health.get("provider") != PROVIDER
        or not isinstance(health.get("schemas"), Mapping)
    ):
        return publish_health(datastore_root)
    usage_path = root / "state" / "consumer-usage.json"
    try:
        usage = json.loads(usage_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        usage = {}
    counts = usage.get("schema_read_counts", {}) if isinstance(usage, Mapping) else {}
    schemas = {
        str(schema): {
            **dict(item),
            "consumer_read_count": int(counts.get(schema, 0)),
        }
        for schema, item in health["schemas"].items()
        if isinstance(item, Mapping)
    }
    updated = {
        **dict(health),
        "schemas": schemas,
        "consumer_usage_observed_at": utc_timestamp().isoformat(),
    }
    _write_json_atomic(health_path, updated)
    return health_path


def _compact_consumer_usage_event(value: Mapping[str, object]) -> dict[str, object]:
    event = dict(value)
    raw_sources = event.pop("source_files", ())
    if isinstance(raw_sources, (list, tuple)):
        resolved_sources = tuple(sorted({str(item) for item in raw_sources}))
        event.setdefault("source_file_count", len(resolved_sources))
        event.setdefault(
            "source_files_sha256",
            hashlib.sha256("\n".join(resolved_sources).encode("utf-8")).hexdigest(),
        )
        event.setdefault("source_file_examples", list(resolved_sources[:8]))
    return event


def compact_consumer_usage(datastore_root: Path) -> Path:
    """Migrate the usage ledger to compact v2 lineage without changing counts."""

    path = canonical_root(datastore_root) / "state" / "consumer-usage.json"
    if not path.is_file():
        return path
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise OpraSyncError("OPRA consumer-usage state is unreadable") from exc
    if not isinstance(payload, Mapping):
        raise OpraSyncError("OPRA consumer-usage state is not an object")
    events = [
        _compact_consumer_usage_event(value)
        for value in payload.get("events", ())
        if isinstance(value, Mapping)
    ]
    _write_json_atomic(
        path,
        {
            "schema_version": "databento-opra-consumer-usage-v2",
            "schema_read_counts": dict(payload.get("schema_read_counts", {})),
            "events": events[-1_000:],
        },
    )
    return path


def _synchronize_daily_batch(
    client: object,
    *,
    datastore_root: Path,
    entitlement: Mapping[str, object],
    schema: str,
    days: Sequence[str],
    symbols: Sequence[str],
    reporter: Callable[[str], None] | None,
) -> _SyncProgress:
    """Resume or submit daily-split jobs while retaining canonical daily output."""

    ordered_days = tuple(dict.fromkeys(sorted(str(day) for day in days)))
    planned = set(ordered_days)
    verified_no_data = _batch_verified_no_data_dates(
        datastore_root,
        schema=schema,
        symbols=symbols,
    )
    progress = _SyncProgress()
    satisfied: set[str] = set()
    existing: set[str] = set()
    for day in ordered_days:
        destination = partition_directory(
            datastore_root,
            schema=schema,
            day=day,
            symbols=symbols,
        )
        if destination.is_dir():
            verified = verify_partition(destination, datastore_root=datastore_root)
            progress.skipped_partitions += 1
            progress.completed_rows += int(
                verified["manifest"]["normalized"]["row_count"]
            )
            progress.completed_bytes += int(
                verified["manifest"]["normalized"]["size_bytes"]
            )
            existing.add(day)
            satisfied.add(day)
        elif day in verified_no_data:
            progress.skipped_partitions += 1
            satisfied.add(day)

    missing = planned.difference(satisfied)
    if reporter:
        reporter(
            f"BATCH_SCAN {schema}/{symbol_scope_name(symbols)} "
            f"verified_existing={len(existing)} verified_no_data="
            f"{len(satisfied.difference(existing))} missing={len(missing)}"
        )

    for state_path, state in _batch_job_states(
        datastore_root,
        schema=schema,
        symbols=symbols,
    ):
        if str(state.get("status")) == "COMPLETE":
            continue
        state_days = set(str(value) for value in state["planned_dates"])
        if not state_days.issubset(planned):
            continue
        target_days = state_days.intersection(missing)
        if not target_days and not state_days.issubset(satisfied):
            continue
        resumed = _execute_batch_job_state(
            client,
            datastore_root=datastore_root,
            entitlement=entitlement,
            schema=schema,
            symbols=symbols,
            state_path=state_path,
            state=state,
            target_days=target_days,
            reporter=reporter,
        )
        progress.absorb(resumed)
        missing.difference_update(state_days)

    for group in _missing_batch_groups(ordered_days, missing):
        if len(group) < OPRA_BATCH_MIN_DAYS:
            if reporter:
                reporter(
                    f"STREAMING_SHORT_GAP {schema}/{symbol_scope_name(symbols)} "
                    f"days={len(group)} range={group[0]}..{group[-1]}"
                )
            current = _execute_stream_plan(
                client,
                datastore_root=datastore_root,
                entitlement=entitlement,
                symbols=symbols,
                plan=[(schema, day) for day in group],
                reporter=reporter,
                fail_fast=True,
            )
            progress.absorb(current)
            missing.difference_update(group)
            continue
        request_start = group[0]
        request_end = (date.fromisoformat(group[-1]) + timedelta(days=1)).isoformat()
        state_path, state = _load_or_submit_batch_job(
            client,
            datastore_root=datastore_root,
            schema=schema,
            symbols=symbols,
            start=request_start,
            end=request_end,
            planned_dates=group,
            reporter=reporter,
        )
        current = _execute_batch_job_state(
            client,
            datastore_root=datastore_root,
            entitlement=entitlement,
            schema=schema,
            symbols=symbols,
            state_path=state_path,
            state=state,
            target_days=set(group),
            reporter=reporter,
        )
        progress.absorb(current)
        missing.difference_update(group)

    if missing:
        raise OpraSyncError(
            f"Batch synchronization left {len(missing)} uncovered {schema} dates"
        )
    return progress


def _missing_batch_groups(
    ordered_days: Sequence[str], missing: set[str]
) -> list[tuple[str, ...]]:
    groups: list[tuple[str, ...]] = []
    current: list[str] = []
    for day in ordered_days:
        if day in missing:
            current.append(day)
        elif current:
            groups.append(tuple(current))
            current = []
    if current:
        groups.append(tuple(current))
    return groups


def _opra_batch_api(client: object) -> object:
    batch = getattr(client, "batch", None)
    required = ("submit_job", "get_job_details", "list_files", "download")
    if batch is None or not all(callable(getattr(batch, name, None)) for name in required):
        raise OpraSyncError(
            "Installed Databento client does not provide the required OPRA batch API"
        )
    return batch


def _batch_job_request(
    *, schema: str, symbols: Sequence[str], start: str, end: str
) -> dict[str, object]:
    return {
        "dataset": DATASET,
        "schema": schema,
        "symbols": list(symbols),
        "stype_in": "parent",
        "stype_out": "instrument_id",
        "start": start,
        "end": end,
        "encoding": "dbn",
        "compression": "zstd",
        "split_duration": "day",
        "delivery": "download",
    }


def _batch_job_directory(
    datastore_root: Path,
    *,
    schema: str,
    symbols: Sequence[str],
    start: str,
    end: str,
) -> Path:
    return (
        canonical_root(datastore_root)
        / "state"
        / "batch-jobs"
        / clean_token(schema)
        / symbol_scope_name(symbols)
        / window_name(start, end)
    )


def _batch_download_directory(
    datastore_root: Path,
    *,
    schema: str,
    symbols: Sequence[str],
    start: str,
    end: str,
) -> Path:
    return (
        canonical_root(datastore_root)
        / ".staging"
        / "batch-jobs"
        / clean_token(schema)
        / symbol_scope_name(symbols)
        / window_name(start, end)
        / "downloads"
    )


def _batch_job_states(
    datastore_root: Path,
    *,
    schema: str,
    symbols: Sequence[str],
) -> list[tuple[Path, dict[str, object]]]:
    root = (
        canonical_root(datastore_root)
        / "state"
        / "batch-jobs"
        / clean_token(schema)
        / symbol_scope_name(symbols)
    )
    output: list[tuple[Path, dict[str, object]]] = []
    for path in sorted(root.glob("*/job.json")):
        output.append(
            (
                path,
                _load_batch_job_state(
                    path,
                    expected_schema=schema,
                    expected_symbols=symbols,
                ),
            )
        )
    return output


def _batch_verified_no_data_dates(
    datastore_root: Path,
    *,
    schema: str,
    symbols: Sequence[str],
) -> set[str]:
    output: set[str] = set()
    for _path, state in _batch_job_states(
        datastore_root,
        schema=schema,
        symbols=symbols,
    ):
        if str(state.get("status")) == "COMPLETE":
            output.update(str(value) for value in state.get("no_data_dates", ()))
    return output


def _load_or_submit_batch_job(
    client: object,
    *,
    datastore_root: Path,
    schema: str,
    symbols: Sequence[str],
    start: str,
    end: str,
    planned_dates: Sequence[str],
    reporter: Callable[[str], None] | None,
) -> tuple[Path, dict[str, object]]:
    directory = _batch_job_directory(datastore_root, schema=schema, symbols=symbols, start=start, end=end)
    # Batch preparation and the canonical fetcher share submission identity.
    # The canonical partition writer still owns the ordinary OPRA sync lock.
    with interprocess_file_lock(directory / "submission.lock"):
        return _load_or_submit_batch_job_unlocked(client, datastore_root=datastore_root,
            schema=schema, symbols=symbols, start=start, end=end,
            planned_dates=planned_dates, reporter=reporter)


def _load_or_submit_batch_job_unlocked(
    client: object,
    *,
    datastore_root: Path,
    schema: str,
    symbols: Sequence[str],
    start: str,
    end: str,
    planned_dates: Sequence[str],
    reporter: Callable[[str], None] | None,
) -> tuple[Path, dict[str, object]]:
    directory = _batch_job_directory(
        datastore_root,
        schema=schema,
        symbols=symbols,
        start=start,
        end=end,
    )
    path = directory / "job.json"
    request = _batch_job_request(
        schema=schema,
        symbols=symbols,
        start=start,
        end=end,
    )
    if path.is_file():
        state = _load_batch_job_state(
            path,
            expected_schema=schema,
            expected_symbols=symbols,
        )
        if state["request"] != request or tuple(state["planned_dates"]) != tuple(
            planned_dates
        ):
            raise OpraSyncError(f"OPRA batch state does not match requested range: {path}")
        return path, state

    batch = _opra_batch_api(client)
    response = getattr(batch, "submit_job")(
        dataset=DATASET,
        schema=schema,
        symbols=list(symbols),
        stype_in="parent",
        stype_out="instrument_id",
        start=start,
        end=end,
        encoding="dbn",
        compression="zstd",
        split_duration="day",
        delivery="download",
    )
    if not isinstance(response, Mapping):
        raise OpraSyncError("Databento OPRA batch submission returned malformed details")
    job_id = str(response.get("id", "")).strip()
    if not job_id or _BATCH_JOB_ID_RE.fullmatch(job_id) is None:
        raise OpraSyncError("Databento OPRA batch submission returned an unsafe job ID")
    state = {
        "schema_version": BATCH_JOB_VERSION,
        "status": "SUBMITTED",
        "request": request,
        "request_checksum_sha256": _semantic_checksum(request),
        "planned_dates": list(planned_dates),
        "job_id": job_id,
        "submitted_at": utc_timestamp().isoformat(),
    }
    _write_json_exclusive(path, state)
    if reporter:
        reporter(
            f"SUBMITTED_BATCH {schema}/{symbol_scope_name(symbols)} "
            f"job={job_id} days={len(planned_dates)} range={start}..{end}"
        )
    return path, state


def _load_batch_job_state(
    path: Path,
    *,
    expected_schema: str,
    expected_symbols: Sequence[str],
) -> dict[str, object]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise OpraSyncError(f"OPRA batch state is unreadable: {path}") from exc
    if not isinstance(payload, dict) or payload.get("schema_version") != BATCH_JOB_VERSION:
        raise OpraSyncError(f"OPRA batch state version is invalid: {path}")
    request = payload.get("request")
    planned_dates = payload.get("planned_dates")
    job_id = str(payload.get("job_id", "")).strip()
    if (
        not isinstance(request, Mapping)
        or request.get("dataset") != DATASET
        or request.get("schema") != expected_schema
        or tuple(str(value) for value in request.get("symbols", ()))
        != tuple(str(value) for value in expected_symbols)
        or payload.get("request_checksum_sha256") != _semantic_checksum(request)
        or not isinstance(planned_dates, list)
        or not planned_dates
        or not job_id
        or _BATCH_JOB_ID_RE.fullmatch(job_id) is None
    ):
        raise OpraSyncError(f"OPRA batch state identity is invalid: {path}")
    normalized_dates = tuple(str(value) for value in planned_dates)
    if normalized_dates != tuple(sorted(set(normalized_dates))):
        raise OpraSyncError(f"OPRA batch state dates are invalid: {path}")
    status = str(payload.get("status", ""))
    if status not in {"SUBMITTED", "DONE", "FILES_READY", "COMPLETE"}:
        raise OpraSyncError(f"OPRA batch state status is invalid: {path}")
    if status == "COMPLETE":
        completion = _batch_completion_body(payload)
        if payload.get("completion_checksum_sha256") != _semantic_checksum(completion):
            raise OpraSyncError(f"OPRA batch completion checksum is invalid: {path}")
        covered = set(str(value) for value in payload.get("published_dates", ()))
        covered.update(str(value) for value in payload.get("no_data_dates", ()))
        if covered != set(normalized_dates):
            raise OpraSyncError(f"OPRA batch completion coverage is invalid: {path}")
    return payload


def _batch_completion_body(state: Mapping[str, object]) -> dict[str, object]:
    return {
        "request": dict(state["request"]),
        "request_checksum_sha256": state["request_checksum_sha256"],
        "planned_dates": list(state["planned_dates"]),
        "job_id": state["job_id"],
        "provider_files": list(state.get("provider_files", ())),
        "published_dates": list(state.get("published_dates", ())),
        "no_data_dates": list(state.get("no_data_dates", ())),
    }


def _update_batch_job_state(
    path: Path,
    state: Mapping[str, object],
    **updates: object,
) -> dict[str, object]:
    payload = {**dict(state), **updates}
    if payload.get("status") == "COMPLETE":
        payload["completion_checksum_sha256"] = _semantic_checksum(
            _batch_completion_body(payload)
        )
    _write_json_atomic(path, payload)
    return payload


def _execute_batch_job_state(
    client: object,
    *,
    datastore_root: Path,
    entitlement: Mapping[str, object],
    schema: str,
    symbols: Sequence[str],
    state_path: Path,
    state: Mapping[str, object],
    target_days: set[str],
    reporter: Callable[[str], None] | None,
) -> _SyncProgress:
    current = dict(state)
    if str(current.get("status")) == "COMPLETE":
        return _SyncProgress(skipped_partitions=len(target_days))
    current = _wait_for_batch_job(
        client,
        state_path=state_path,
        state=current,
        reporter=reporter,
    )
    current = _prepare_batch_job_files(
        client,
        datastore_root=datastore_root,
        state_path=state_path,
        state=current,
        schema=schema,
        symbols=symbols,
        reporter=reporter,
    )
    planned_dates = set(str(value) for value in current["planned_dates"])
    provider_files = list(current.get("provider_files", ()))
    data_dates = {str(item["day"]) for item in provider_files if isinstance(item, Mapping)}
    if not data_dates.issubset(planned_dates):
        raise OpraSyncError("Databento OPRA batch returned files outside planned dates")
    no_data_dates = planned_dates.difference(data_dates)
    progress = _SyncProgress()
    processed = 0
    for raw_info in sorted(provider_files, key=lambda value: str(value["day"])):
        if not isinstance(raw_info, Mapping):
            raise OpraSyncError("Databento OPRA batch file inventory is malformed")
        day = str(raw_info["day"])
        destination = partition_directory(
            datastore_root,
            schema=schema,
            day=day,
            symbols=symbols,
        )
        source = _batch_local_file(
            datastore_root,
            state=current,
            schema=schema,
            symbols=symbols,
            filename=str(raw_info["filename"]),
        )
        if destination.is_dir():
            if day in target_days:
                verified = verify_partition(destination, datastore_root=datastore_root)
                progress.skipped_partitions += 1
                progress.completed_rows += int(
                    verified["manifest"]["normalized"]["row_count"]
                )
                progress.completed_bytes += int(
                    verified["manifest"]["normalized"]["size_bytes"]
                )
            if source.is_file():
                _verify_batch_source_file(source, raw_info)
                try:
                    source.unlink()
                except OSError:
                    pass
            continue
        _verify_batch_source_file(source, raw_info)
        try:
            manifest = _download_partition(
                client,
                datastore_root=datastore_root,
                entitlement=entitlement,
                schema=schema,
                day=day,
                symbols=symbols,
                provider_file=source,
                provider_delivery={
                    "mode": "batch",
                    "job_id": current["job_id"],
                    "filename": raw_info["filename"],
                    "provider_hash": raw_info["hash"],
                },
            )
        except Exception as exc:
            raise OpraSyncError(
                f"Databento OPRA batch file failed canonical publication: "
                f"{raw_info['filename']}: {type(exc).__name__}: {exc}"
            ) from exc
        progress.completed_partitions += 1
        progress.completed_rows += int(manifest["normalized"]["row_count"])
        progress.completed_bytes += int(manifest["normalized"]["size_bytes"])
        try:
            source.unlink()
        except OSError:
            pass
        processed += 1
        if reporter and (
            processed % OPRA_BATCH_PROGRESS_FILES == 0 or processed == len(provider_files)
        ):
            reporter(
                f"BATCH_PROGRESS {schema}/{symbol_scope_name(symbols)} "
                f"job={current['job_id']} files={processed}/{len(provider_files)} "
                f"rows={progress.completed_rows}"
            )

    target_no_data = no_data_dates.intersection(target_days)
    progress.skipped_partitions += len(target_no_data)
    completed = _update_batch_job_state(
        state_path,
        current,
        status="COMPLETE",
        published_dates=sorted(data_dates),
        no_data_dates=sorted(no_data_dates),
        completed_at=utc_timestamp().isoformat(),
    )
    _load_batch_job_state(
        state_path,
        expected_schema=schema,
        expected_symbols=symbols,
    )
    if reporter:
        reporter(
            f"COMPLETED_BATCH {schema}/{symbol_scope_name(symbols)} "
            f"job={completed['job_id']} published={len(data_dates)} "
            f"no_data={len(no_data_dates)}"
        )
    return progress


def _wait_for_batch_job(
    client: object,
    *,
    state_path: Path,
    state: Mapping[str, object],
    reporter: Callable[[str], None] | None,
) -> dict[str, object]:
    if str(state.get("status")) in {"DONE", "FILES_READY"}:
        return dict(state)
    batch = _opra_batch_api(client)
    job_id = str(state["job_id"])
    last_report: tuple[str, object] | None = None
    while True:
        details = getattr(batch, "get_job_details")(job_id)
        if not isinstance(details, Mapping):
            raise OpraSyncError(f"Databento OPRA batch job {job_id} returned malformed details")
        provider_state = str(details.get("state", "")).lower()
        progress = details.get("progress")
        report_key = (provider_state, progress)
        if reporter and report_key != last_report:
            reporter(
                f"WAITING_BATCH job={job_id} state={provider_state or 'unknown'} "
                f"progress={progress if progress is not None else 'unknown'}"
            )
            last_report = report_key
        if provider_state == "done":
            selected = {
                key: details.get(key)
                for key in (
                    "id",
                    "state",
                    "record_count",
                    "billed_size",
                    "actual_size",
                    "cost_usd",
                    "ts_received",
                    "ts_process_start",
                    "ts_process_done",
                    "ts_expiration",
                )
            }
            return _update_batch_job_state(
                state_path,
                state,
                status="DONE",
                provider_job=selected,
                provider_done_at=utc_timestamp().isoformat(),
            )
        if provider_state == "expired":
            raise OpraSyncError(
                f"Databento OPRA batch job expired before local completion: {job_id}"
            )
        if provider_state not in {"received", "queued", "processing"}:
            raise OpraSyncError(
                f"Databento OPRA batch job has unexpected state {provider_state!r}: {job_id}"
            )
        time.sleep(OPRA_BATCH_POLL_SECONDS)


def _prepare_batch_job_files(
    client: object,
    *,
    datastore_root: Path,
    state_path: Path,
    state: Mapping[str, object],
    schema: str,
    symbols: Sequence[str],
    reporter: Callable[[str], None] | None,
) -> dict[str, object]:
    current = dict(state)
    provider_files = current.get("provider_files")
    if provider_files is None:
        batch = _opra_batch_api(client)
        response = getattr(batch, "list_files")(str(current["job_id"]))
        if not isinstance(response, list) or not all(
            isinstance(item, Mapping) for item in response
        ):
            raise OpraSyncError("Databento OPRA batch returned a malformed file list")
        request = current["request"]
        if not isinstance(request, Mapping):
            raise OpraSyncError("Databento OPRA batch state has a malformed request")
        provider_files, ignored_provider_files = _batch_data_file_inventory(
            response,
            planned_dates=tuple(str(value) for value in current["planned_dates"]),
            request_start=str(request["start"]),
            request_end=str(request["end"]),
        )
        current = _update_batch_job_state(
            state_path,
            current,
            provider_files=provider_files,
            ignored_provider_files=ignored_provider_files,
        )
        if reporter and ignored_provider_files:
            reporter(
                f"IGNORED_UNAVAILABLE_BATCH_FILES "
                f"{schema}/{symbol_scope_name(symbols)} job={current['job_id']} "
                f"files={len(ignored_provider_files)}"
            )
    elif not isinstance(provider_files, list) or not all(
        isinstance(item, Mapping) for item in provider_files
    ):
        raise OpraSyncError("Databento OPRA batch state has malformed file inventory")

    missing_sources: list[Mapping[str, object]] = []
    for info in provider_files:
        day = str(info["day"])
        destination = partition_directory(
            datastore_root,
            schema=schema,
            day=day,
            symbols=symbols,
        )
        if destination.is_dir():
            continue
        source = _batch_local_file(
            datastore_root,
            state=current,
            schema=schema,
            symbols=symbols,
            filename=str(info["filename"]),
        )
        if source.is_file():
            _verify_batch_source_file(source, info)
        else:
            missing_sources.append(info)

    if missing_sources:
        if reporter:
            total_size = sum(int(item["size"]) for item in missing_sources)
            reporter(
                f"DOWNLOADING_BATCH {schema}/{symbol_scope_name(symbols)} "
                f"job={current['job_id']} files={len(missing_sources)} "
                f"bytes={total_size}"
            )
        _download_batch_archive(
            client,
            datastore_root=datastore_root,
            state=current,
            schema=schema,
            symbols=symbols,
            required_files=missing_sources,
        )
    for info in provider_files:
        day = str(info["day"])
        destination = partition_directory(
            datastore_root,
            schema=schema,
            day=day,
            symbols=symbols,
        )
        if destination.is_dir():
            continue
        _verify_batch_source_file(
            _batch_local_file(
                datastore_root,
                state=current,
                schema=schema,
                symbols=symbols,
                filename=str(info["filename"]),
            ),
            info,
        )
    return _update_batch_job_state(
        state_path,
        current,
        status="FILES_READY",
        files_ready_at=utc_timestamp().isoformat(),
    )


def _batch_data_file_inventory(
    response: Sequence[Mapping[str, object]],
    *,
    planned_dates: Sequence[str],
    request_start: str,
    request_end: str,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    planned = set(planned_dates)
    request_start_date = date.fromisoformat(request_start)
    request_end_date = date.fromisoformat(request_end)
    output: list[dict[str, object]] = []
    ignored: list[dict[str, object]] = []
    seen_days: set[str] = set()
    for item in response:
        filename = str(item.get("filename", "")).strip()
        if not filename.endswith(".dbn.zst"):
            continue
        if not filename or Path(filename).name != filename:
            raise OpraSyncError("Databento OPRA batch returned an unsafe filename")
        size = int(item.get("size", -1))
        if size <= 0:
            raise OpraSyncError(f"Databento OPRA batch returned invalid size for {filename}")
        provider_hash = _normalized_provider_hash(item.get("hash"))
        day = _batch_filename_day(filename)
        day_value = date.fromisoformat(day)
        if not request_start_date <= day_value < request_end_date:
            raise OpraSyncError(
                f"Databento OPRA batch returned a file outside its request "
                f"range: {filename}"
            )
        if day in seen_days:
            raise OpraSyncError(
                f"Databento OPRA batch returned multiple DBN files for {day}"
            )
        seen_days.add(day)
        file_info = {
            "filename": filename,
            "size": size,
            "hash": provider_hash,
            "day": day,
        }
        if day in planned:
            output.append(file_info)
        else:
            # Batch requests cover one continuous range, while the canonical
            # plan intentionally includes only provider-available dates. The
            # provider may still package a degraded date inside that range;
            # retain its inventory as evidence, but do not publish it as a
            # checksum-verified canonical partition.
            ignored.append(file_info)
    output.sort(key=lambda value: str(value["day"]))
    ignored.sort(key=lambda value: str(value["day"]))
    return output, ignored


def _batch_filename_day(filename: str) -> str:
    candidates: set[str] = set()
    for match in _BATCH_FILE_DATE_RE.findall(filename):
        try:
            candidates.add(date.fromisoformat(f"{match[:4]}-{match[4:6]}-{match[6:]}").isoformat())
        except ValueError:
            continue
    if len(candidates) != 1:
        raise OpraSyncError(
            f"Databento OPRA batch filename has no unambiguous UTC date: {filename}"
        )
    return next(iter(candidates))


def _normalized_provider_hash(value: object) -> str:
    text = str(value or "").strip().lower()
    algorithm, separator, digest = text.partition(":")
    if not separator and len(text) == 64:
        algorithm, digest = "sha256", text
    if algorithm != "sha256" or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise OpraSyncError("Databento OPRA batch file has no valid SHA-256")
    return f"sha256:{digest}"


def _batch_local_file(
    datastore_root: Path,
    *,
    state: Mapping[str, object],
    schema: str,
    symbols: Sequence[str],
    filename: str,
) -> Path:
    request = state["request"]
    assert isinstance(request, Mapping)
    return (
        _batch_download_directory(
            datastore_root,
            schema=schema,
            symbols=symbols,
            start=str(request["start"]),
            end=str(request["end"]),
        )
        / str(state["job_id"])
        / filename
    )


def _verify_batch_source_file(path: Path, info: Mapping[str, object]) -> None:
    expected_hash = str(info["hash"]).partition(":")[2]
    if (
        not path.is_file()
        or path.stat().st_size != int(info["size"])
        or file_checksum(path) != expected_hash
    ):
        raise OpraSyncError(f"Databento OPRA batch file verification failed: {path}")


def _download_batch_archive(
    client: object,
    *,
    datastore_root: Path,
    state: Mapping[str, object],
    schema: str,
    symbols: Sequence[str],
    required_files: Sequence[Mapping[str, object]],
) -> None:
    request = state["request"]
    assert isinstance(request, Mapping)
    download_root = _batch_download_directory(
        datastore_root,
        schema=schema,
        symbols=symbols,
        start=str(request["start"]),
        end=str(request["end"]),
    )
    download_root.mkdir(parents=True, exist_ok=True)
    batch = _opra_batch_api(client)
    downloaded = getattr(batch, "download")(
        job_id=str(state["job_id"]),
        output_dir=download_root,
        keep_zip=True,
    )
    if not isinstance(downloaded, list) or len(downloaded) != 1:
        raise OpraSyncError("Databento OPRA batch archive download returned malformed paths")
    archive_path = Path(downloaded[0]).resolve()
    resolved_root = download_root.resolve()
    if resolved_root not in archive_path.parents or archive_path.suffix.lower() != ".zip":
        raise OpraSyncError("Databento OPRA batch archive escaped its staging root")
    expected = {str(item["filename"]): item for item in required_files}
    try:
        with zipfile.ZipFile(archive_path) as archive:
            members: dict[str, zipfile.ZipInfo] = {}
            for member in archive.infolist():
                if member.is_dir():
                    continue
                parts = PurePosixPath(member.filename).parts
                if (
                    not parts
                    or PurePosixPath(member.filename).is_absolute()
                    or any(part in {"", ".", ".."} for part in parts)
                ):
                    raise OpraSyncError(
                        "Databento OPRA batch archive contains an unsafe member"
                    )
                basename = parts[-1]
                if basename in expected:
                    if basename in members:
                        raise OpraSyncError(
                            f"Databento OPRA batch archive duplicates {basename}"
                        )
                    members[basename] = member
            missing = sorted(set(expected).difference(members))
            if missing:
                raise OpraSyncError(
                    "Databento OPRA batch archive omitted expected files: "
                    + ", ".join(missing[:5])
                )
            job_root = download_root / str(state["job_id"])
            job_root.mkdir(parents=True, exist_ok=True)
            for filename, info in expected.items():
                target = job_root / filename
                if target.is_file():
                    _verify_batch_source_file(target, info)
                    continue
                pending = _next_pending_file(target)
                with archive.open(members[filename]) as source, pending.open("xb") as destination:
                    shutil.copyfileobj(source, destination, length=8 * 1024**2)
                _verify_batch_source_file(pending, info)
                pending.replace(target)
    except (OSError, zipfile.BadZipFile) as exc:
        raise OpraSyncError("Databento OPRA batch archive is unreadable") from exc
    finally:
        try:
            archive_path.unlink()
        except OSError:
            pass


def _live_replay_partition_clock(schema: str) -> str:
    # CBBO's event timestamp can predate its sampled quote. Keep legacy
    # Historical receipt validation unchanged while using the receive/sample
    # clock for this explicitly scoped replay publication.
    return "ts_recv" if schema == "cbbo-1m" else "ts_event"


def _validate_live_replay_publication(
    delivery: Mapping[str, object],
    *,
    request: object,
    raw_path: Path,
    segment: object,
) -> None:
    from datafetching.databento_opra_replay import validate_replay_delivery

    if (
        not isinstance(request, Mapping)
        or request.get("dataset") != DATASET
        or request.get("schema") not in OPRA_STRATEGY_HISTORY_SCHEMAS
        or request.get("stype_in") != "parent"
        or not request.get("symbols")
        or "ALL_SYMBOLS" in request["symbols"]
        or not isinstance(segment, str)
        or not segment.strip()
        or segment == "full-day"
    ):
        raise OpraSyncError("Live replay requires a scoped strategy-schema segment")
    try:
        validate_replay_delivery(delivery, request=request, raw_path=raw_path)
    except Exception as exc:
        raise OpraSyncError(f"Databento live replay evidence is invalid: {exc}") from exc


def _filter_live_replay_parquet(
    path: Path, *, schema: str, start: str, end: str
) -> Mapping[str, object]:
    """Retain the exact half-open scope; preserve the entire native DBN separately."""
    clock = _live_replay_partition_clock(schema)
    parquet = pq.ParquetFile(path)
    if clock not in parquet.schema_arrow.names:
        raise OpraSyncError("Databento replay lacks its requested partition clock")
    start_ts = pd.to_datetime(start, utc=True, errors="raise")
    end_ts = pd.to_datetime(end, utc=True, errors="raise")
    if start_ts >= end_ts:
        raise OpraSyncError("Databento replay normalization interval is empty or reversed")
    clock_type = pa.timestamp("ns", tz="UTC")
    lower = pa.scalar(start_ts, type=clock_type)
    upper = pa.scalar(end_ts, type=clock_type)
    pending = _next_pending_file(path)
    before = after = kept = 0
    try:
        with pq.ParquetWriter(pending, parquet.schema_arrow, compression="zstd") as writer:
            for batch in parquet.iter_batches(batch_size=250_000):
                timestamps = pc.cast(batch.column(batch.schema.get_field_index(clock)), clock_type)
                if timestamps.null_count:
                    raise OpraSyncError("Databento replay contains null partition timestamps")
                too_early = pc.less(timestamps, lower)
                too_late = pc.greater_equal(timestamps, upper)
                before += int(pc.sum(pc.cast(too_early, pa.int64())).as_py() or 0)
                after += int(pc.sum(pc.cast(too_late, pa.int64())).as_py() or 0)
                selected = batch.filter(pc.invert(pc.or_(too_early, too_late)))
                writer.write_batch(selected)
                kept += selected.num_rows
    finally:
        parquet.close()
    if kept == 0:
        raise OpraSyncError("Databento replay has no records in the requested interval")
    pending.replace(path)
    return {
        "method": "exact-half-open-replay-interval-v1",
        "partition_timestamp_column": clock,
        "start": start_ts.isoformat(),
        "end": end_ts.isoformat(),
        "input_row_count": before + kept + after,
        "before_start_rows_removed": before,
        "at_or_after_end_rows_removed": after,
        "output_row_count": kept,
    }


def _verify_live_replay_normalization(
    manifest: Mapping[str, object],
    validation: Mapping[str, object],
    parquet_path: Path,
) -> None:
    delivery = manifest["provider_delivery"]
    request = manifest["request"]
    evidence = delivery.get("normalization_filter")
    if not isinstance(evidence, Mapping):
        raise OpraSyncError("Databento replay lacks normalization interval evidence")
    schema = str(manifest["schema"])
    try:
        start = pd.to_datetime(request["start"], utc=True, errors="raise")
        end = pd.to_datetime(request["end"], utc=True, errors="raise")
        earliest = pd.to_datetime(validation["earliest_partition_timestamp"], utc=True)
        latest = pd.to_datetime(validation["latest_partition_timestamp"], utc=True)
        counts = tuple(
            evidence[key]
            for key in (
                "input_row_count", "before_start_rows_removed",
                "at_or_after_end_rows_removed", "output_row_count",
            )
        )
        complete = (
            manifest["dataset"] == request["dataset"] == DATASET
            and schema == request["schema"]
            and start == pd.to_datetime(manifest["partition_start"], utc=True)
            and end == pd.to_datetime(manifest["partition_end"], utc=True)
            and start == pd.to_datetime(evidence["start"], utc=True)
            and end == pd.to_datetime(evidence["end"], utc=True)
            and start < end
            and not pd.isna(earliest)
            and not pd.isna(latest)
            and start <= earliest <= latest < end
            and evidence.get("method") == "exact-half-open-replay-interval-v1"
            and evidence.get("partition_timestamp_column") == _live_replay_partition_clock(schema)
            and all(type(value) is int and value >= 0 for value in counts)
            and counts[0] == sum(counts[1:])
            and counts[0] == delivery.get("data_record_count")
            and counts[3] == validation["row_count"]
            and counts[3] > 0
            and delivery.get("normalized_symbol_mapping") == "complete"
            and validation["duplicate_natural_key_rows"] == 0
            and validation["null_counts"].get(_live_replay_partition_clock(schema)) == 0
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise OpraSyncError("Databento replay normalization evidence is malformed") from exc
    if not complete:
        raise OpraSyncError("Databento replay normalization evidence is inconsistent")
    try:
        symbols = pq.read_table(parquet_path, columns=["symbol"]).column("symbol")
        missing_symbols = symbols.null_count or pc.any(
            pc.equal(pc.utf8_trim_whitespace(symbols), "")
        ).as_py()
    except (pa.ArrowException, KeyError) as exc:
        raise OpraSyncError("Databento replay normalized symbol mapping is unreadable") from exc
    if missing_symbols:
        raise OpraSyncError("Databento replay normalized symbol mapping is incomplete")


def _download_partition(
    client: object,
    *,
    datastore_root: Path,
    entitlement: Mapping[str, object],
    schema: str,
    day: str,
    symbols: Sequence[str],
    request_start: str | None = None,
    request_end: str | None = None,
    segment: str | None = None,
    provider_file: Path | None = None,
    provider_delivery: Mapping[str, object] | None = None,
) -> Mapping[str, object]:
    live_replay = (provider_delivery or {}).get("mode") == "live-intraday-replay"
    if live_replay and provider_file is None:
        raise OpraSyncError("Live replay publication requires its retained native DBN")
    destination = partition_directory(
        datastore_root,
        schema=schema,
        day=day,
        symbols=symbols,
        segment=segment,
    )
    staging_root = canonical_root(datastore_root) / ".staging"
    staging = _next_attempt_directory(
        staging_root
        / clean_token(schema)
        / symbol_scope_name(symbols)
        / clean_token(day)
        / clean_token(segment or "full-day")
    )
    staging.mkdir(parents=True, exist_ok=False)
    raw_path = staging / ("provider.dbn" if live_replay else "provider.dbn.zst")
    parquet_path = staging / "normalized.parquet"
    next_day = (date.fromisoformat(day) + timedelta(days=1)).isoformat()
    effective_start = request_start or day
    effective_end = request_end or next_day
    request = {
        "dataset": DATASET,
        "schema": schema,
        "start": effective_start,
        "end": effective_end,
        "symbols": list(symbols) if symbols else ["ALL_SYMBOLS"],
        "stype_in": "parent" if symbols else "raw_symbol",
    }
    kwargs = dict(request)
    kwargs["path"] = raw_path
    store: object | None = None
    partially_resolved_symbol_count = 0
    partially_resolved_symbols_checksum: str | None = None
    symbol_mapping_fallback: Mapping[str, object] | None = None
    replay_filter: Mapping[str, object] | None = None
    try:
        if provider_file is None:
            try:
                store = _retry(
                    getattr(client, "timeseries").get_range,
                    kwargs=kwargs,
                    operation=f"{schema} {day} download",
                )
            except OpraSyncError as exc:
                message = str(exc)
                if (
                    symbols
                    and "symbology_invalid_request" in message
                    and "Could not resolve smart symbols" in message
                ):
                    raise OpraNoDataError(
                        "provider returned no resolvable parent-symbol data"
                    ) from None
                raise
        else:
            source = Path(provider_file).resolve()
            if not source.is_file() or source.stat().st_size == 0:
                raise OpraSyncError("Databento source DBN is missing or empty")
            shutil.copy2(source, raw_path)
            if live_replay:
                _validate_live_replay_publication(
                    provider_delivery, request=request, raw_path=raw_path, segment=segment
                )
                store = _load_dbn_store(raw_path)
            else:
                store = _load_dbn_store(raw_path)
                partially_resolved_symbol_count = _validate_dbn_request_metadata(
                    store,
                    request=request,
                    allow_partially_resolved_symbols=True,
                )
            if partially_resolved_symbol_count:
                partial_symbols = sorted(
                    str(value) for value in getattr(store.metadata, "partial")
                )
                partially_resolved_symbols_checksum = _semantic_checksum(
                    {"partial": partial_symbols}
                )
        if not raw_path.is_file() or raw_path.stat().st_size == 0:
            raise OpraSyncError("Databento returned no provider-native DBN file")
        if store is None:
            store = _load_dbn_store(raw_path)
        try:
            if live_replay:
                # Live files contain system and symbol-mapping messages as well
                # as market records, and have open-ended native metadata.
                store.to_parquet(parquet_path, map_symbols=True, schema=schema)
            else:
                store.to_parquet(parquet_path, map_symbols=True)
        except Exception as exc:
            raise OpraSyncError("Databento DBN normalization failed") from exc
        finally:
            # Databento's DBN reader retains an open file handle on Windows.
            # Release it before inspecting the native file or atomically
            # publishing the completed directory.
            store = None
            gc.collect()
        if not parquet_path.is_file():
            if live_replay:
                raise OpraSyncError("Databento replay normalization produced no Parquet")
            _classify_missing_parquet(
                raw_path,
                request=request,
                allow_partially_resolved_symbols=provider_file is not None,
            )
        if live_replay:
            replay_filter = _filter_live_replay_parquet(
                parquet_path,
                schema=schema,
                start=effective_start,
                end=effective_end,
            )
        _add_tcbbo_source_record_identity(
            raw_path,
            parquet_path,
            schema=schema,
        )
        provider_duplicates_removed = _deduplicate_normalized_parquet(
            parquet_path,
            schema=schema,
        )
        validation = validate_parquet(
            parquet_path,
            schema=schema,
            partition_timestamp_column=(
                _live_replay_partition_clock(schema) if live_replay else None
            ),
        )
        start_ts = pd.to_datetime(effective_start, utc=True)
        end_ts = pd.to_datetime(effective_end, utc=True)
        earliest = pd.to_datetime(
            validation["earliest_partition_timestamp"], utc=True, errors="coerce"
        )
        latest = pd.to_datetime(
            validation["latest_partition_timestamp"], utc=True, errors="coerce"
        )
        if int(validation["row_count"]) < 1:
            raise OpraSyncError("Databento normalized Parquet is empty")
        if pd.isna(earliest) or pd.isna(latest) or earliest < start_ts or latest >= end_ts:
            raise OpraSyncError(
                "Databento partition-clock timestamps escape the requested interval"
            )
        symbol_null_rows = _normalized_symbol_null_rows(parquet_path)
        if not symbol_null_rows.empty:
            provider_filename = str(
                (provider_delivery or {}).get("filename", raw_path.name)
            )
            if (
                provider_file is not None
                and (provider_delivery or {}).get("mode") == "batch"
                and schema in _BATCH_DEFINITION_FALLBACK_SCHEMAS
                and partially_resolved_symbol_count
                and symbols
            ):
                try:
                    symbol_mapping_fallback = _repair_batch_ohlcv_symbol_mapping(
                        client,
                        parquet_path=parquet_path,
                        definition_path=staging / _BATCH_DEFINITION_FALLBACK_FILENAME,
                        schema=schema,
                        day=day,
                        symbols=symbols,
                        unresolved_rows=symbol_null_rows,
                    )
                except Exception as exc:
                    raise _batch_symbol_mapping_error(
                        filename=provider_filename,
                        unresolved_rows=symbol_null_rows,
                        reason=f"{type(exc).__name__}: {exc}",
                    ) from exc
                validation = validate_parquet(parquet_path, schema=schema)
                symbol_null_rows = _normalized_symbol_null_rows(parquet_path)
            if not symbol_null_rows.empty:
                raise _batch_symbol_mapping_error(
                    filename=provider_filename,
                    unresolved_rows=symbol_null_rows,
                    reason="no verified point-in-time definition mapping was applied",
                )
        if int(validation["duplicate_natural_key_rows"]) != 0:
            raise OpraSyncError("Databento partition contains duplicate natural keys")
        raw_inventory = {
            "path": raw_path.name,
            "size_bytes": raw_path.stat().st_size,
            "checksum_sha256": file_checksum(raw_path),
        }
        if live_replay:
            delivery_evidence = {
                **dict(provider_delivery),
                "normalized_symbol_mapping": "complete",
                "normalization_filter": dict(replay_filter),
            }
        elif provider_delivery is not None:
            provider_hash = str(provider_delivery.get("provider_hash", ""))
            if (
                provider_delivery.get("mode") != "batch"
                or not str(provider_delivery.get("job_id", "")).strip()
                or not str(provider_delivery.get("filename", "")).strip()
                or provider_hash.partition(":")[0] != "sha256"
                or provider_hash.partition(":")[2] != raw_inventory["checksum_sha256"]
            ):
                raise OpraSyncError("Databento batch delivery evidence does not match raw DBN")
            delivery_evidence = {
                **dict(provider_delivery),
                "partially_resolved_symbol_count": partially_resolved_symbol_count,
                "partially_resolved_symbols_checksum_sha256": (
                    partially_resolved_symbols_checksum
                ),
                "normalized_symbol_mapping": "complete",
            }
            if symbol_mapping_fallback is not None:
                delivery_evidence["symbol_mapping_fallback"] = dict(
                    symbol_mapping_fallback
                )
        else:
            delivery_evidence = {"mode": "timeseries-stream"}
        normalized_inventory = {
            "path": parquet_path.name,
            "size_bytes": parquet_path.stat().st_size,
            "checksum_sha256": file_checksum(parquet_path),
            "provider_duplicate_rows_removed": provider_duplicates_removed,
            **validation,
        }
        manifest = {
            "schema_version": PARTITION_VERSION,
            "sync_version": SYNC_VERSION,
            "provider": PROVIDER,
            "dataset": DATASET,
            "schema": schema,
            "level": "L0" if schema in L0_SCHEMAS else "L1",
            "partition_date": day,
            "partition_start": start_ts.isoformat(),
            "partition_end": end_ts.isoformat(),
            "time_segment": segment,
            "symbol_scope": symbol_scope_name(symbols),
            "request": request,
            "provider_entitlement": dict(entitlement["entitlements"][schema]),
            "provider_delivery": delivery_evidence,
            "published_at": utc_timestamp().isoformat(),
            "raw": raw_inventory,
            "normalized": normalized_inventory,
        }
        if live_replay:
            _verify_live_replay_normalization(manifest, validation, parquet_path)
        manifest_path = staging / "manifest.json"
        _write_json_exclusive(manifest_path, manifest)
        receipt = {
            "schema_version": RECEIPT_VERSION,
            "provider": PROVIDER,
            "dataset": DATASET,
            "schema": schema,
            "partition_date": day,
            "partition_start": manifest["partition_start"],
            "partition_end": manifest["partition_end"],
            "time_segment": segment,
            "published_at": manifest["published_at"],
            "manifest_checksum_sha256": file_checksum(manifest_path),
            "raw_checksum_sha256": raw_inventory["checksum_sha256"],
            "normalized_checksum_sha256": normalized_inventory["checksum_sha256"],
            "provider_duplicate_rows_removed": provider_duplicates_removed,
        }
        _write_json_exclusive(staging / "receipt.json", receipt)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            raise OpraSyncError("An OPRA partition appeared during atomic publication")
        staging.replace(destination)
        return verify_partition(destination, datastore_root=datastore_root)["manifest"]
    except Exception:
        # Preserve failed staging in place for diagnosis. Moving it while the
        # SDK still owns a Windows file handle can mask the original exception.
        raise


def _classify_missing_parquet(
    raw_path: Path,
    *,
    request: Mapping[str, object],
    allow_partially_resolved_symbols: bool = False,
) -> None:
    """Raise NO_DATA only for a request-matching DBN that cleanly has no records."""

    reopened = None
    records = None
    try:
        with warnings.catch_warnings(record=True) as parser_warnings:
            warnings.simplefilter("always")
            reopened = _load_dbn_store(raw_path)
            _validate_dbn_request_metadata(
                reopened,
                request=request,
                allow_partially_resolved_symbols=allow_partially_resolved_symbols,
            )
            records = iter(reopened)
            sentinel = object()
            first_record = next(records, sentinel)
        if parser_warnings:
            raise OpraSyncError(
                "Databento DBN parsing emitted warnings after normalization "
                "produced no Parquet"
            )
        if first_record is not sentinel:
            raise OpraSyncError(
                "Databento DBN contains records but normalization produced no Parquet"
            )
    except OpraSyncError:
        raise
    except Exception as exc:
        raise OpraSyncError(
            "Databento DBN is unreadable after normalization produced no Parquet"
        ) from exc
    finally:
        records = None
        reopened = None
        gc.collect()
    raise OpraNoDataError("provider returned a readable zero-record DBN")


def _load_dbn_store(path: Path) -> object:
    import databento as db

    return db.DBNStore.from_file(path)


def _normalized_symbol_null_rows(path: Path) -> pd.DataFrame:
    parquet = pq.ParquetFile(path)
    names = tuple(parquet.schema_arrow.names)
    timestamp_column = _event_column(names)
    selected = [
        name
        for name in (timestamp_column, "publisher_id", "instrument_id", "symbol")
        if name is not None and name in names
    ]
    if "instrument_id" not in selected:
        raise OpraSyncError("Databento normalized Parquet has no instrument ID")
    table = pq.read_table(path, columns=selected)
    if "symbol" in names:
        table = table.filter(pc.is_null(table.column("symbol")))
    frame = table.to_pandas()
    if frame.index.name and frame.index.name not in frame.columns:
        frame = frame.reset_index()
    if "symbol" not in frame.columns:
        frame["symbol"] = None
    return frame


def _batch_symbol_mapping_error(
    *,
    filename: str,
    unresolved_rows: pd.DataFrame,
    reason: str,
) -> OpraSyncError:
    instrument_ids = sorted(
        {int(value) for value in unresolved_rows["instrument_id"].tolist()}
    )
    return OpraSyncError(
        "Databento normalized symbol mapping remains unresolved: "
        f"filename={filename} null_count={len(unresolved_rows)} "
        f"instrument_ids={instrument_ids}; {reason}"
    )


def _repair_batch_ohlcv_symbol_mapping(
    client: object,
    *,
    parquet_path: Path,
    definition_path: Path,
    schema: str,
    day: str,
    symbols: Sequence[str],
    unresolved_rows: pd.DataFrame,
) -> Mapping[str, object]:
    """Repair selected batch OHLCV nulls backed by exact-day definitions."""

    if schema not in _BATCH_DEFINITION_FALLBACK_SCHEMAS:
        raise OpraSyncError(
            f"Point-in-time definition fallback is not allowed for schema={schema}"
        )

    instrument_ids = sorted(
        {int(value) for value in unresolved_rows["instrument_id"].tolist()}
    )
    next_day = (date.fromisoformat(day) + timedelta(days=1)).isoformat()
    request = {
        "dataset": DATASET,
        "schema": "definition",
        "start": day,
        "end": next_day,
        "symbols": [str(value) for value in instrument_ids],
        "stype_in": "instrument_id",
        "stype_out": "instrument_id",
    }
    definition_store: object | None = None
    try:
        definition_store = _retry(
            getattr(client, "timeseries").get_range,
            kwargs={**request, "path": definition_path},
            operation=f"{schema} {day} point-in-time definition lookup",
            maximum_attempts=1,
        )
        _validate_dbn_request_metadata(definition_store, request=request)
        if not definition_path.is_file() or definition_path.stat().st_size == 0:
            raise OpraSyncError(
                "Databento point-in-time definition lookup retained no native DBN"
            )
        definitions = definition_store.to_df(map_symbols=False)
        if not isinstance(definitions, pd.DataFrame):
            raise OpraSyncError(
                "Databento point-in-time definition lookup returned no DataFrame"
            )
        if definitions.index.name and definitions.index.name not in definitions.columns:
            definitions = definitions.reset_index()
        resolved, mapping_evidence = _definition_symbol_mapping(
            definition_store,
            definitions=definitions,
            unresolved_rows=unresolved_rows,
            schema=schema,
            day=day,
            symbols=symbols,
        )
    finally:
        definition_store = None
        gc.collect()

    _fill_null_symbols(parquet_path, resolved)
    remaining = _normalized_symbol_null_rows(parquet_path)
    if not remaining.empty:
        raise OpraSyncError(
            "Point-in-time definition repair left normalized symbol nulls"
        )
    source_inventory = {
        "path": definition_path.name,
        "size_bytes": definition_path.stat().st_size,
        "checksum_sha256": file_checksum(definition_path),
    }
    return {
        "method": (
            "same-day-instrument-definition-v1"
            if schema == "ohlcv-1d"
            else "same-day-instrument-definition-v2"
        ),
        "schema": schema,
        "request": request,
        "source": source_inventory,
        "original_null_symbol_count": len(unresolved_rows),
        "affected_instrument_ids": instrument_ids,
        "mappings": mapping_evidence,
        "post_repair_null_symbol_count": 0,
    }


def _definition_symbol_mapping(
    store: object,
    *,
    definitions: pd.DataFrame,
    unresolved_rows: pd.DataFrame,
    schema: str,
    day: str,
    symbols: Sequence[str],
) -> tuple[dict[int, str], list[dict[str, object]]]:
    if schema not in _BATCH_DEFINITION_FALLBACK_SCHEMAS:
        raise OpraSyncError(
            f"Point-in-time definition fallback is not allowed for schema={schema}"
        )
    required_columns = {
        "ts_event",
        "instrument_id",
        "raw_symbol",
        "security_update_action",
        "instrument_class",
        "raw_instrument_id",
        "channel_id",
        "asset",
    }
    missing_columns = sorted(required_columns.difference(definitions.columns))
    if missing_columns:
        raise OpraSyncError(
            "Databento point-in-time definitions lack required fields: "
            + ", ".join(missing_columns)
        )
    allowed_assets = _option_parent_assets(symbols)
    start_ts = pd.Timestamp(day, tz="UTC")
    end_ts = start_ts + pd.Timedelta(days=1)
    frame = definitions.copy()
    frame["instrument_id"] = pd.to_numeric(frame["instrument_id"], errors="coerce")
    frame["raw_instrument_id"] = pd.to_numeric(
        frame["raw_instrument_id"], errors="coerce"
    )
    frame["ts_event"] = pd.to_datetime(frame["ts_event"], utc=True, errors="coerce")
    target_ids = sorted(
        {int(value) for value in unresolved_rows["instrument_id"].tolist()}
    )
    frame = frame.loc[frame["instrument_id"].isin(target_ids)].copy()
    mappings = getattr(getattr(store, "metadata"), "mappings", None)
    if not isinstance(mappings, Mapping):
        raise OpraSyncError(
            "Databento point-in-time definitions have no mapping intervals"
        )

    timestamp_column = _event_column(tuple(unresolved_rows.columns))
    if timestamp_column is None:
        raise OpraSyncError("Normalized null-symbol rows have no event timestamp")
    unresolved_timestamps = pd.to_datetime(
        unresolved_rows[timestamp_column], utc=True, errors="coerce"
    )
    if unresolved_timestamps.isna().any():
        raise OpraSyncError("Normalized null-symbol rows have invalid timestamps")

    resolved: dict[int, str] = {}
    evidence: list[dict[str, object]] = []
    for instrument_id in target_ids:
        rows = frame.loc[frame["instrument_id"] == instrument_id].copy()
        if rows.empty:
            raise OpraSyncError(
                f"No same-day definition record exists for instrument_id={instrument_id}"
            )
        if (
            rows["ts_event"].isna().any()
            or (rows["ts_event"] < start_ts).any()
            or (rows["ts_event"] >= end_ts).any()
        ):
            raise OpraSyncError(
                f"Definition records escape the requested day for instrument_id={instrument_id}"
            )
        rows["raw_symbol"] = rows["raw_symbol"].map(lambda value: str(value).strip())
        rows["asset"] = rows["asset"].map(lambda value: str(value).strip())
        rows["instrument_class"] = rows["instrument_class"].map(
            lambda value: str(value).strip()
        )
        rows["security_update_action"] = rows["security_update_action"].map(
            lambda value: str(value).strip()
        )
        raw_symbols = sorted(set(rows["raw_symbol"]).difference({""}))
        if len(raw_symbols) != 1:
            raise OpraSyncError(
                f"Ambiguous same-day definitions for instrument_id={instrument_id}"
            )
        if not set(rows["asset"]).issubset(allowed_assets):
            raise OpraSyncError(
                f"Definition parent identity does not match for instrument_id={instrument_id}"
            )
        if not set(rows["instrument_class"]).issubset({"C", "P"}):
            raise OpraSyncError(
                f"Definition is not an option for instrument_id={instrument_id}"
            )
        if "D" in set(rows["security_update_action"]):
            raise OpraSyncError(
                f"Definition was deleted during the day for instrument_id={instrument_id}"
            )
        if not (rows["raw_instrument_id"] == instrument_id).all():
            raise OpraSyncError(
                f"Definition raw instrument identity differs for instrument_id={instrument_id}"
            )
        affected_timestamps = unresolved_timestamps.loc[
            unresolved_rows["instrument_id"].astype("int64") == instrument_id
        ]
        if affected_timestamps.empty:
            raise OpraSyncError(
                f"No affected timestamps exist for instrument_id={instrument_id}"
            )
        interval_start, interval_end = _covering_identity_interval(
            mappings,
            instrument_id=instrument_id,
            timestamps=affected_timestamps,
        )
        record_timestamp_coverage = "daily-bucket-date-interval"
        activation_timestamp: pd.Timestamp | None = None
        if schema == "ohlcv-1h":
            additions = rows.loc[rows["security_update_action"] == "A"]
            if additions.empty:
                raise OpraSyncError(
                    "No same-day definition activation exists for "
                    f"instrument_id={instrument_id}"
                )
            activation_timestamp = additions["ts_event"].min()
            if pd.isna(activation_timestamp) or (
                activation_timestamp > affected_timestamps.min()
            ):
                raise OpraSyncError(
                    "Definition activation timestamp does not cover every normalized "
                    f"record timestamp for instrument_id={instrument_id}"
                )
            record_timestamp_coverage = "definition-activation-at-or-before-record"
        raw_symbol = raw_symbols[0]
        resolved[instrument_id] = raw_symbol
        mapping_evidence: dict[str, object] = {
            "instrument_id": instrument_id,
            "raw_symbol": raw_symbol,
            "asset": rows["asset"].iloc[0],
            "mapping_interval_start": interval_start,
            "mapping_interval_end": interval_end,
            "definition_record_count": len(rows),
            "earliest_definition_timestamp": rows["ts_event"].min().isoformat(),
            "latest_definition_timestamp": rows["ts_event"].max().isoformat(),
            "earliest_affected_timestamp": affected_timestamps.min().isoformat(),
            "latest_affected_timestamp": affected_timestamps.max().isoformat(),
            "record_timestamp_coverage": record_timestamp_coverage,
            "channel_ids": sorted({int(value) for value in rows["channel_id"]}),
        }
        if activation_timestamp is not None:
            mapping_evidence["definition_activation_timestamp"] = (
                activation_timestamp.isoformat()
            )
        evidence.append(mapping_evidence)
    return resolved, evidence


def _option_parent_assets(symbols: Sequence[str]) -> set[str]:
    assets: set[str] = set()
    for symbol in symbols:
        value = str(symbol).strip()
        if not value.endswith(".OPT") or not value[:-4]:
            raise OpraSyncError(
                "Point-in-time definition fallback requires OPRA parent option symbols"
            )
        assets.add(value[:-4])
    return assets


def _covering_identity_interval(
    mappings: Mapping[object, object],
    *,
    instrument_id: int,
    timestamps: pd.Series,
) -> tuple[str, str]:
    raw_intervals = mappings.get(str(instrument_id), mappings.get(instrument_id))
    if not isinstance(raw_intervals, (list, tuple)):
        raise OpraSyncError(
            f"No definition mapping interval exists for instrument_id={instrument_id}"
        )
    candidates: list[tuple[date, date]] = []
    timestamp_dates = [value.date() for value in timestamps]
    for raw_interval in raw_intervals:
        if not isinstance(raw_interval, Mapping):
            continue
        try:
            start = date.fromisoformat(str(raw_interval["start_date"]))
            end = date.fromisoformat(str(raw_interval["end_date"]))
        except (KeyError, TypeError, ValueError):
            continue
        if (
            str(raw_interval.get("symbol")) == str(instrument_id)
            and start < end
            and timestamp_dates
            and all(start <= value < end for value in timestamp_dates)
        ):
            candidates.append((start, end))
    if len(candidates) != 1:
        raise OpraSyncError(
            "Definition mapping interval does not uniquely cover every normalized "
            f"record timestamp for instrument_id={instrument_id}"
        )
    return candidates[0][0].isoformat(), candidates[0][1].isoformat()


def _fill_null_symbols(path: Path, mappings: Mapping[int, str]) -> None:
    table = pq.read_table(path)
    if "symbol" not in table.column_names:
        raise OpraSyncError("Databento normalized Parquet has no symbol column")
    instrument_ids = table.column("instrument_id").to_pylist()
    symbols = table.column("symbol").to_pylist()
    for instrument_id, replacement in mappings.items():
        existing = {
            str(symbol)
            for row_instrument_id, symbol in zip(instrument_ids, symbols, strict=True)
            if int(row_instrument_id) == instrument_id and symbol is not None
        }
        if existing and existing != {replacement}:
            raise OpraSyncError(
                "Point-in-time definition conflicts with an existing normalized symbol "
                f"for instrument_id={instrument_id}"
            )
    repaired: list[object] = []
    for instrument_id, symbol in zip(instrument_ids, symbols, strict=True):
        if symbol is not None:
            repaired.append(symbol)
            continue
        replacement = mappings.get(int(instrument_id))
        if not replacement:
            raise OpraSyncError(
                f"No verified symbol replacement exists for instrument_id={instrument_id}"
            )
        repaired.append(replacement)
    symbol_index = table.column_names.index("symbol")
    symbol_type = table.schema.field(symbol_index).type
    table = table.set_column(
        symbol_index,
        "symbol",
        pa.array(repaired, type=symbol_type),
    )
    pending = _next_pending_file(path)
    pq.write_table(table, pending, compression="zstd")
    pending.replace(path)


def _verify_symbol_mapping_fallback_evidence(
    directory: Path,
    evidence: object,
    *,
    schema: str,
) -> None:
    if not isinstance(evidence, Mapping):
        raise OpraSyncError("OPRA partition symbol fallback evidence is malformed")
    source = evidence.get("source")
    mappings = evidence.get("mappings")
    affected = evidence.get("affected_instrument_ids")
    if (
        evidence.get("method")
        not in {
            "same-day-instrument-definition-v1",
            "same-day-instrument-definition-v2",
        }
        or not isinstance(source, Mapping)
        or not isinstance(mappings, list)
        or not isinstance(affected, list)
        or not affected
        or int(evidence.get("original_null_symbol_count", 0)) < 1
        or evidence.get("post_repair_null_symbol_count") != 0
    ):
        raise OpraSyncError("OPRA partition symbol fallback evidence is incomplete")
    source_name = str(source.get("path", ""))
    source_path = directory / source_name
    if (
        source_name != _BATCH_DEFINITION_FALLBACK_FILENAME
        or not source_path.is_file()
        or source_path.stat().st_size != int(source.get("size_bytes", -1))
        or file_checksum(source_path) != source.get("checksum_sha256")
    ):
        raise OpraSyncError("OPRA partition symbol fallback checksum verification failed")
    mapped_ids = sorted(
        int(item.get("instrument_id"))
        for item in mappings
        if isinstance(item, Mapping)
        and str(item.get("raw_symbol", "")).strip()
        and str(item.get("mapping_interval_start", "")).strip()
        and str(item.get("mapping_interval_end", "")).strip()
    )
    if mapped_ids != sorted(int(value) for value in affected):
        raise OpraSyncError("OPRA partition symbol fallback mappings are incomplete")
    if schema == "ohlcv-1h":
        if (
            evidence.get("method") != "same-day-instrument-definition-v2"
            or evidence.get("schema") != schema
        ):
            raise OpraSyncError(
                "OPRA hourly partition symbol fallback evidence is incomplete"
            )
        for item in mappings:
            if not isinstance(item, Mapping):
                raise OpraSyncError(
                    "OPRA hourly partition symbol fallback mappings are malformed"
                )
            activation = pd.to_datetime(
                item.get("definition_activation_timestamp"),
                utc=True,
                errors="coerce",
            )
            earliest = pd.to_datetime(
                item.get("earliest_affected_timestamp"),
                utc=True,
                errors="coerce",
            )
            latest = pd.to_datetime(
                item.get("latest_affected_timestamp"),
                utc=True,
                errors="coerce",
            )
            if (
                item.get("record_timestamp_coverage")
                != "definition-activation-at-or-before-record"
                or pd.isna(activation)
                or pd.isna(earliest)
                or pd.isna(latest)
                or activation > earliest
                or earliest > latest
            ):
                raise OpraSyncError(
                    "OPRA hourly partition symbol fallback timestamp evidence is invalid"
                )


def _validate_dbn_request_metadata(
    store: object,
    *,
    request: Mapping[str, object],
    allow_partially_resolved_symbols: bool = False,
) -> int:
    """Validate native DBN identity and return its partial-symbol count."""

    metadata = getattr(store, "metadata")
    expected_start = pd.to_datetime(request["start"], utc=True, errors="raise")
    expected_end = pd.to_datetime(request["end"], utc=True, errors="raise")
    actual_start = pd.to_datetime(getattr(store, "start"), utc=True, errors="raise")
    actual_end = pd.to_datetime(getattr(store, "end"), utc=True, errors="raise")
    expected_symbols = tuple(str(value) for value in request["symbols"])
    actual_symbols = tuple(str(value) for value in getattr(store, "symbols"))
    matches_request = (
        str(getattr(store, "dataset")) == str(request["dataset"])
        and str(getattr(store, "schema")) == str(request["schema"])
        and actual_start == expected_start
        and actual_end == expected_end
        and actual_symbols == expected_symbols
        and str(getattr(store, "stype_in")) == str(request["stype_in"])
        and str(getattr(store, "stype_out")) == "instrument_id"
        and getattr(store, "limit") is None
    )
    version = getattr(metadata, "version", None)
    partial = getattr(metadata, "partial", None)
    not_found = getattr(metadata, "not_found", None)
    structurally_complete = (
        isinstance(version, int)
        and version >= 1
        and isinstance(partial, (list, tuple))
        and all(isinstance(value, str) for value in partial)
        and (allow_partially_resolved_symbols or not partial)
        and isinstance(not_found, (list, tuple))
        and all(isinstance(value, str) for value in not_found)
        and not not_found
        and getattr(metadata, "ts_out", None) is False
    )
    if not matches_request or not structurally_complete:
        raise OpraSyncError(
            "Databento DBN request metadata does not match the normalization request"
        )
    return len(partial)


def _partition_plan(
    client: object,
    *,
    entitlement: Mapping[str, object],
    scope: SyncScope,
) -> list[tuple[str, str]]:
    metadata = getattr(client, "metadata")
    output: list[tuple[str, str]] = []
    for schema, start, end in _scope_ranges(entitlement, scope):
        conditions = _retry(
            metadata.get_dataset_condition,
            kwargs={"dataset": DATASET, "start_date": start, "end_date": end},
            operation=f"{schema} dataset conditions",
        )
        for condition in conditions:
            condition_date = str(condition.get("date"))
            if (
                str(condition.get("condition")) == "available"
                and start <= condition_date < end
            ):
                output.append((schema, condition_date))
    return output


def _partition_time_segments(
    client: object,
    *,
    schema: str,
    day: str,
    symbols: Sequence[str],
) -> list[tuple[str, str, str | None]]:
    """Split exceptionally dense daily schemas into deterministic UTC intervals."""

    start = pd.Timestamp(day, tz="UTC")
    end = start + pd.Timedelta(days=1)
    if schema not in HIGH_VOLUME_SCHEMAS:
        return [(start.isoformat(), end.isoformat(), None)]

    metadata = getattr(client, "metadata")
    output: list[tuple[str, str, str | None]] = []

    def visit(interval_start: pd.Timestamp, interval_end: pd.Timestamp, *, split: bool) -> None:
        record_count = int(
            _retry(
                getattr(metadata, "get_record_count"),
                kwargs=_metadata_request_kwargs(
                    schema=schema,
                    start=interval_start.isoformat(),
                    end=interval_end.isoformat(),
                    symbols=symbols,
                ),
                operation=f"{schema} time-partition record count",
            )
        )
        if record_count == 0:
            return
        duration_seconds = (interval_end - interval_start).total_seconds()
        if record_count <= TARGET_HIGH_VOLUME_PARTITION_ROWS or (
            duration_seconds <= 60 and record_count <= MAX_EXACT_VALIDATION_ROWS
        ):
            segment = None
            if split:
                segment = _time_segment_token(interval_start, interval_end)
            output.append(
                (interval_start.isoformat(), interval_end.isoformat(), segment)
            )
            return

        if duration_seconds <= MINIMUM_TIME_PARTITION_SECONDS:
            raise OpraSyncError(
                f"{schema} has {record_count:,} records in the minimum "
                f"{MINIMUM_TIME_PARTITION_SECONDS}-second interval "
                f"{interval_start.isoformat()} to {interval_end.isoformat()}"
            )
        midpoint = (interval_start + (interval_end - interval_start) / 2).floor("s")
        if midpoint <= interval_start or midpoint >= interval_end:
            raise OpraSyncError(
                f"Unable to split dense {schema} interval "
                f"{interval_start.isoformat()} to {interval_end.isoformat()}"
            )
        visit(interval_start, midpoint, split=True)
        visit(midpoint, interval_end, split=True)

    visit(start, end, split=False)
    return output


def _time_segment_token(start: pd.Timestamp, end: pd.Timestamp) -> str:
    def token(value: pd.Timestamp) -> str:
        text = value.strftime("%H%M%S%f")
        return text[:6] if text.endswith("000000") else text.rstrip("0")

    return f"{token(start)}-{token(end)}"


def _scope_ranges(
    entitlement: Mapping[str, object], scope: SyncScope
) -> list[tuple[str, str, str]]:
    entitlements = entitlement.get("entitlements")
    if not isinstance(entitlements, Mapping):
        raise OpraSyncError("Entitlement receipt has no schema bounds")
    schemas = tuple(dict.fromkeys(str(value) for value in scope.schemas))
    invalid = sorted(set(schemas).difference(STANDARD_SCHEMAS))
    if invalid:
        raise ValueError("Unsupported OPRA schemas: " + ", ".join(invalid))
    output: list[tuple[str, str, str]] = []
    for schema in schemas:
        item = entitlements[schema]
        if not isinstance(item, Mapping):
            raise OpraSyncError(f"Entitlement receipt has malformed bounds for {schema}")
        entitled_start = date.fromisoformat(str(item["entitled_start"]))
        entitled_end = date.fromisoformat(str(item["entitled_end"]))
        requested_start = (
            date.fromisoformat(scope.start) if scope.start else entitled_start
        )
        requested_end = date.fromisoformat(scope.end) if scope.end else entitled_end
        if requested_start < entitled_start or requested_end > entitled_end:
            raise OpraSyncError(
                f"Requested OPRA {schema} scope is outside the configured included "
                f"Standard-plan window: requested={requested_start.isoformat()}.."
                f"{requested_end.isoformat()} included={entitled_start.isoformat()}.."
                f"{entitled_end.isoformat()} authority={STANDARD_PLAN_AUTHORITY}"
            )
        if requested_start >= requested_end:
            raise OpraSyncError(
                f"Requested OPRA {schema} scope is empty or reversed: "
                f"{requested_start.isoformat()}..{requested_end.isoformat()}"
            )
        output.append(
            (schema, requested_start.isoformat(), requested_end.isoformat())
        )
    if not output:
        raise OpraSyncError("Requested OPRA scope does not overlap the entitlement")
    return output


def standard_plan_history_policy(schema: str) -> dict[str, object]:
    """Return the conservative included OPRA window from the plan authority."""

    if schema in L0_SCHEMAS:
        return {"unit": "years", "value": 13}
    if schema in L1_SCHEMAS:
        return {"unit": "months", "value": 12}
    raise ValueError(f"Unsupported OPRA schema: {schema}")


def _history_window_start(end: str, policy: Mapping[str, object]) -> str:
    anchor = pd.Timestamp(end)
    amount = int(policy["value"])
    unit = str(policy["unit"])
    if unit == "years":
        start = anchor - pd.DateOffset(years=amount)
    elif unit == "months":
        start = anchor - pd.DateOffset(months=amount)
    else:
        raise ValueError(f"Unsupported OPRA included-history policy: {policy}")
    return start.date().isoformat()


def _metadata_request_kwargs(
    *, schema: str, start: str, end: str, symbols: Sequence[str]
) -> dict[str, object]:
    return {
        "dataset": DATASET,
        "schema": schema,
        "start": start,
        "end": end,
        "symbols": list(symbols) if symbols else "ALL_SYMBOLS",
        "stype_in": "parent" if symbols else "raw_symbol",
    }


def _publish_cursor(datastore_root: Path, *, schema: str) -> None:
    manifests = list(
        canonical_root(datastore_root).glob(
            f"{clean_token(schema)}/*/dates/*/segments/*/manifest.json"
        )
    )
    completed_dates = sorted({path.parents[2].name for path in manifests})
    payload = {
        "schema_version": "databento-opra-cursor-v1",
        "provider": PROVIDER,
        "dataset": DATASET,
        "schema": schema,
        "updated_at": utc_timestamp().isoformat(),
        "completed_partition_dates": completed_dates,
        "latest_completed_partition_date": completed_dates[-1] if completed_dates else None,
    }
    _write_json_atomic(canonical_root(datastore_root) / "state" / f"{schema}.json", payload)


def _duplicate_rows(path: Path, *, columns: Sequence[str], row_count: int) -> int:
    if not columns or row_count == 0:
        return 0
    # Exact validation is deliberately bounded to partitions small enough for a
    # practical normalized publication. Larger partitions must be split before
    # publication instead of receiving an approximate duplicate report.
    if row_count > MAX_EXACT_VALIDATION_ROWS:
        raise OpraSyncError(
            f"Normalized partition exceeds the {MAX_EXACT_VALIDATION_ROWS:,}-row "
            "exact-validation bound; "
            "reduce the date/symbol partition"
        )
    keys = pd.read_parquet(path, columns=list(columns))
    if keys.index.name in columns:
        keys = keys.reset_index()
    return int(keys.duplicated(list(columns), keep=False).sum())


def _deduplicate_normalized_parquet(path: Path, *, schema: str) -> int:
    """Remove exact provider duplicates from canonical CMBP while retaining raw DBN."""

    if schema != "cmbp-1":
        return 0
    frame = pd.read_parquet(path)
    index_name = frame.index.name
    if index_name:
        frame = frame.reset_index()
    key = tuple(name for name in _natural_key(schema) if name in frame.columns)
    if not key:
        raise OpraSyncError("CMBP normalized Parquet has no deduplication key")
    original_rows = len(frame)
    frame = frame.drop_duplicates(list(key), keep="first")
    removed = original_rows - len(frame)
    if removed:
        if index_name and index_name in frame.columns:
            frame = frame.set_index(index_name)
        temporary = _next_pending_file(path)
        frame.to_parquet(temporary, compression="zstd")
        temporary.replace(path)
    return removed


def _add_tcbbo_source_record_identity(
    raw_path: Path,
    parquet_path: Path,
    *,
    schema: str,
) -> Mapping[str, object] | None:
    """Retain lossless TCBBO multiplicity using immutable native DBN order."""

    if schema != "tcbbo":
        return None
    table = pq.read_table(parquet_path)
    if _TCBBO_SOURCE_ORDINAL_COLUMN in table.column_names:
        raise OpraSyncError(
            f"TCBBO normalized Parquet already contains {_TCBBO_SOURCE_ORDINAL_COLUMN}"
        )
    native_store: object | None = None
    native_records: object | None = None
    try:
        native_store = _load_dbn_store(raw_path)
        native_records = iter(native_store)
        native_record_count = sum(1 for _record in native_records)
    except Exception as exc:
        raise OpraSyncError(
            "TCBBO native DBN record-count verification failed"
        ) from exc
    finally:
        native_records = None
        native_store = None
        gc.collect()
    if native_record_count != table.num_rows:
        raise OpraSyncError(
            "TCBBO normalization did not preserve every native record: "
            f"native_rows={native_record_count} normalized_rows={table.num_rows}"
        )
    table = table.append_column(
        _TCBBO_SOURCE_ORDINAL_COLUMN,
        pa.array(range(table.num_rows), type=pa.uint64()),
    )
    pending = _next_pending_file(parquet_path)
    pq.write_table(table, pending, compression="zstd")
    pending.replace(parquet_path)
    return {
        "column": _TCBBO_SOURCE_ORDINAL_COLUMN,
        "basis": _TCBBO_SOURCE_ORDINAL_BASIS,
        "record_count": table.num_rows,
    }


def _validate_tcbbo_source_record_identity(
    path: Path,
    *,
    row_count: int,
) -> Mapping[str, object]:
    parquet = pq.ParquetFile(path)
    if _TCBBO_SOURCE_ORDINAL_COLUMN not in parquet.schema_arrow.names:
        raise OpraSyncError(
            f"TCBBO normalized Parquet lacks {_TCBBO_SOURCE_ORDINAL_COLUMN}"
        )
    ordinals = pq.read_table(
        path,
        columns=[_TCBBO_SOURCE_ORDINAL_COLUMN],
    ).column(_TCBBO_SOURCE_ORDINAL_COLUMN).combine_chunks()
    expected = pa.array(range(row_count), type=pa.uint64())
    if ordinals.null_count or not ordinals.equals(expected):
        raise OpraSyncError(
            "TCBBO source record ordinals do not exactly preserve native DBN order"
        )
    return {
        "column": _TCBBO_SOURCE_ORDINAL_COLUMN,
        "basis": _TCBBO_SOURCE_ORDINAL_BASIS,
        "record_count": row_count,
    }


def _natural_key(schema: str) -> tuple[str, ...]:
    if schema.startswith("ohlcv-"):
        return ("ts_event", "publisher_id", "instrument_id", "symbol")
    if schema == "definition":
        return ("ts_recv", "publisher_id", "instrument_id", "symbol")
    if schema == "cmbp-1":
        # The Python SDK's normalized CMBP Parquet does not expose the DBN
        # sequence field. Preserve distinct book updates using every normalized
        # message field and remove only byte-for-byte-equivalent market records.
        return (
            "ts_recv",
            "publisher_id",
            "instrument_id",
            "symbol",
            "ts_event",
            "rtype",
            "action",
            "side",
            "price",
            "size",
            "flags",
            "ts_in_delta",
            "bid_px_00",
            "ask_px_00",
            "bid_sz_00",
            "ask_sz_00",
            "bid_pb_00",
            "ask_pb_00",
        )
    if schema == "trades":
        return ("ts_recv", "publisher_id", "instrument_id", "sequence", "symbol")
    if schema == "tcbbo":
        # TCBBO contains every trade event but, unlike Trades and TBBO, its
        # provider schema has no venue sequence field. Native DBN order is the
        # only lossless identity for otherwise byte-equivalent executions.
        return (
            "ts_recv",
            "publisher_id",
            "instrument_id",
            _TCBBO_SOURCE_ORDINAL_COLUMN,
            "symbol",
        )
    if schema.startswith("cbbo-"):
        return ("ts_recv", "publisher_id", "instrument_id", "symbol")
    if schema == "statistics":
        return ("ts_recv", "publisher_id", "instrument_id", "stat_type", "sequence", "symbol")
    return ("ts_recv", "publisher_id", "instrument_id", "symbol")


def _event_column(columns: Sequence[str]) -> str | None:
    return next((name for name in ("ts_event", "ts_recv") if name in columns), None)


def _retry(
    function: Callable[..., object],
    *,
    kwargs: Mapping[str, object],
    operation: str,
    maximum_attempts: int = DOWNLOAD_MAX_ATTEMPTS,
) -> object:
    last_error: Exception | None = None
    for attempt in range(1, maximum_attempts + 1):
        try:
            return function(**kwargs)
        except Exception as exc:
            last_error = exc
            if attempt < maximum_attempts:
                time.sleep(min(2 ** (attempt - 1), 4))
    assert last_error is not None
    raise OpraSyncError(
        f"{operation} failed after {maximum_attempts} attempts: "
        f"{type(last_error).__name__}: {last_error}"
    ) from last_error


def _date_text(value: object) -> str:
    return pd.to_datetime(value, utc=True).date().isoformat()


def _semantic_checksum(payload: Mapping[str, object]) -> str:
    encoded = json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _storage_preflight_path(
    datastore_root: Path,
    payload: Mapping[str, object],
) -> Path:
    scope = payload.get("scope")
    if not isinstance(scope, Mapping):
        raise OpraSyncError("OPRA storage preflight lacks readable scope metadata")
    schemas = tuple(str(value) for value in scope.get("schemas", ()))
    schema_name = (
        "all-standard-schemas"
        if set(schemas) == set(STANDARD_SCHEMAS)
        else "_and_".join(clean_token(value) for value in schemas)
    ) or "no-schemas"
    raw_symbols = tuple(str(value) for value in scope.get("symbols", ()))
    symbols = () if raw_symbols == ("ALL_SYMBOLS",) else raw_symbols
    start = scope.get("start")
    end = scope.get("end")
    if not start or not end:
        raise OpraSyncError("OPRA storage preflight lacks readable date bounds")
    return (
        canonical_root(datastore_root)
        / "metadata"
        / "preflights"
        / schema_name
        / symbol_scope_name(symbols)
        / window_name(str(start), str(end))
        / "preflight.json"
    )


def _next_attempt_directory(base: Path) -> Path:
    for attempt in range(1, 10_000):
        candidate = base / f"attempt-{attempt:03d}"
        if not candidate.exists():
            return candidate
    raise OpraSyncError(f"Too many retained OPRA staging attempts beneath {base}")


def _write_json_exclusive(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(dict(payload), handle, indent=2, sort_keys=True, default=str)
        handle.write("\n")


def _write_json_atomic(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _next_pending_file(path)
    _write_json_exclusive(temporary, payload)
    temporary.replace(path)


def _next_pending_file(path: Path) -> Path:
    for attempt in range(1, 10_000):
        candidate = path.with_name(f"{path.name}.pending-{attempt:03d}")
        if not candidate.exists():
            return candidate
    raise OpraSyncError(f"Too many retained pending files beside {path}")


def _minimum_timestamp_text(left: object, right: object) -> str | None:
    values = [pd.to_datetime(value, utc=True, errors="coerce") for value in (left, right)]
    valid = [value for value in values if not pd.isna(value)]
    return min(valid).isoformat() if valid else None


def _maximum_timestamp_text(left: object, right: object) -> str | None:
    values = [pd.to_datetime(value, utc=True, errors="coerce") for value in (left, right)]
    valid = [value for value in values if not pd.isna(value)]
    return max(valid).isoformat() if valid else None


__all__ = [
    "DATASET",
    "DOWNLOAD_MAX_ATTEMPTS",
    "ENTITLEMENT_VERSION",
    "L0_SCHEMAS",
    "L1_SCHEMAS",
    "OpraCapacityError",
    "OpraSyncError",
    "OPRA_STRATEGY_HISTORY_SCHEMAS",
    "PROVIDER",
    "STANDARD_SCHEMAS",
    "SyncResult",
    "SyncScope",
    "canonical_root",
    "compact_consumer_usage",
    "configure_client",
    "discover_standard_entitlement",
    "iter_verified_partitions",
    "partition_directory",
    "publish_health",
    "publish_storage_preflight",
    "standard_plan_history_policy",
    "record_consumer_usage",
    "refresh_health_consumer_usage",
    "storage_preflight",
    "symbol_bucket",
    "synchronize",
    "validate_parquet",
    "verify_partition",
]
